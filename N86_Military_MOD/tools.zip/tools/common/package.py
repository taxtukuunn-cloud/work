#!/usr/bin/env python3
"""N76〜N105 用：MODフォルダ（cfg・scen・lines・brief）→ 配布フォルダ（CSV・README・読む用シナリオ集・tools.zip・画像一覧）
使い方: python3 package.py <mods/コード>  → /mnt/user-data/outputs/MOD/<outdir>/
"""
import os, sys, re, glob, shutil, zipfile, subprocess, importlib.util, json

COMMON = os.path.dirname(os.path.abspath(__file__))
MOD = os.path.abspath(sys.argv[1])
spec = importlib.util.spec_from_file_location("cfg", os.path.join(MOD, "cfg.py"))
cm = importlib.util.module_from_spec(spec); spec.loader.exec_module(cm)
CFG = cm.CFG
C, OUTN, S = CFG["code"], CFG["outdir"], CFG["stack"]

subprocess.run([sys.executable, os.path.join(COMMON, "gen_v4.py"), MOD], check=True)
card = os.path.join(MOD, "out", OUTN, "Card")
subprocess.run([sys.executable, os.path.join(COMMON, "patch_recall_ui.py"), card, C], check=True)

DST = os.path.join("/mnt/user-data/outputs/MOD", OUTN)
shutil.rmtree(DST, ignore_errors=True)
os.makedirs(os.path.join(DST, "CSV", "Card"))
os.makedirs(os.path.join(DST, "CSV", "Eventlist", "Quest"))
for f in glob.glob(os.path.join(card, "*.txt")):
    shutil.copy(f, os.path.join(DST, "CSV", "Card"))
shutil.copy(os.path.join(MOD, "out", OUTN, "Eventlist", "Quest", f"{C}.txt"), os.path.join(DST, "CSV", "Eventlist", "Quest"))

# 画像一覧
imgs = set()
for f in glob.glob(os.path.join(DST, "CSV", "Card", "*.txt")):
    imgs |= set(re.findall(r"#%s/([\w\-]+\.png)" % C, open(f, encoding="utf-8").read()))
imgs = sorted(imgs)
with open(os.path.join(DST, "画像一覧.txt"), "w", encoding="utf-8", newline="\r\n") as fo:
    fo.write(f"{OUTN} で使う画像（ゲームの Picture\\{C}\\ に置く）  計{len(imgs)}枚\n\n" + "\n".join(imgs) + "\n")

# 読む用シナリオ集
names = {"btl": "戦闘負け", "onani": "オナニー負け", "inochi": "命乞い負け", "onedari": "おねだり負け"}
keys = ["m1", "m2", "m3", "e1", "e2", "e3", "boss"]
spk = {s[0]: s[0][1:] for s in CFG["speakers"]}
out, total = [], 0
for k in keys:
    for r in names:
        p = os.path.join(MOD, "scen", f"{r}_{k}.txt")
        out.append(f"\n==================== {r}_{k}（{names[r]}） ====================\n")
        who = None
        for l in open(p, encoding="utf-8-sig").read().splitlines():
            cmd, _, rest = l.partition(",")
            if cmd == "話者":
                who = "僕" if rest == "相手プレイヤー" else spk.get(rest, rest.lstrip("%"))
            elif cmd == "セリフ":
                out.append(f"{who}「{rest.replace(chr(92)+'n', '')}」"); total += len(rest.replace("\\n", ""))
            elif cmd == "説明":
                out.append(rest.replace("\\n", "\n")); total += len(rest.replace("\\n", ""))
            elif cmd == "射精":
                out.append("（射精）")
with open(os.path.join(DST, f"{OUTN.replace('_MOD','')}_読む用シナリオ集.txt"), "w", encoding="utf-8", newline="\r\n") as fo:
    fo.write(f"{OUTN} 敗北シナリオ28本（読む用。ゲームには入れない）\n" + "\n".join(out) + "\n")

# tools.zip
with zipfile.ZipFile(os.path.join(DST, "tools.zip"), "w", zipfile.ZIP_DEFLATED) as z:
    for f in ["cfg.py", "brief.md"]:
        z.write(os.path.join(MOD, f), f"tools/{f}")
    for sub in ["scen", "lines"]:
        for f in sorted(glob.glob(os.path.join(MOD, sub, "*"))):
            z.write(f, f"tools/{sub}/{os.path.basename(f)}")
    for f in ["gen_v4.py", "cfgkit.py", "patch_recall_ui.py", "check4000.py", "check_lines.py", "STYLE.md", "lines_spec.md", "package.py"]:
        z.write(os.path.join(COMMON, f), f"tools/common/{f}")

M = CFG["master"]
fav = "／".join(f"{d['name']}「{t['name']}」+{t['fav']}" for d in [M] + [CFG["mons"][k] for k in ["e1", "e2", "e3", "boss"]] for t in d["techs"] if t.get("fav"))
ins = "・".join(f"{d['name']}「{t['name']}」" for d in [M] + [CFG["mons"][k] for k in ["e1", "e2", "e3", "boss"]] for t in d["techs"] if t.get("insert"))
fate = "破壊" if CFG.get("mon_fate") == "destroy" else "敵側へ寝返り（コントロール変更）"
readme = f"""{OUTN}  2026-09-28
======================================================
サキュバスデュエル用・個人利用のみ。登場人物は全員20歳以上。
{CFG['quest_name']}

■ 内容
- CSV\\Card\\  カード（{C}_master／mons_e1〜e3・mons_boss／magic_1〜5／{C}_recall＝回想の栞{"／" + C + "_josou＝女装娘（デッキ外）" if CFG.get("josou") else ""}）
- CSV\\Eventlist\\Quest\\{C}.txt  クエスト登録（通常＋【回想バトル】の2行）
- {OUTN.replace('_MOD','')}_読む用シナリオ集.txt  敗北シナリオ28本（本編の書き方・1本約4,000字、合計 約{total//1000}千字。ゲームには入れない）
- 画像一覧.txt  必要な画像 {len(imgs)}枚（まだありません。ComfyUIで作る）
- tools.zip  生成キット（cfg.py・brief.md・scen 28本・lines 5本・共通スクリプト）

■ ゲームへの入れ方
1. CSV\\Card\\*.txt → ゲームの CSV\\Card\\（{C}_recall.txt も必ず一緒に）
2. CSV\\Eventlist\\Quest\\{C}.txt → ゲームの CSV\\EventList\\Quest\\
3. 画像ができたら ゲームの Picture\\{C}\\ へ（画像が無いと画像の行で止まる可能性あり）
4. 回想の栞の共通画像 MOD\\_共通ツール\\Picture\\RecallUI\\recall_panel.png を Picture\\RecallUI\\ へ（1回だけ）
   （ゲーム本体は D:\\GAME\\SuccubusDuel本体\\RJ01149693\\SuccubusDuel_sub\\サキュバスデュエル。本MODのファイル以外は書き換えない）

■ 仕組み
- 累積スタック「{S}」：主人公 相手プレイヤー.${S}（12で敗北）、男モンスター 相手.${S}（6で{fate}）。
  ★得意技だけ加算：{fav}。
  攻撃時のセリフは受けた側の段階（主人公 1-3/4-6/7-9/10-11、モンスター 0-1/2-3/4/5）で4段階×主人公向け／モンスター向け。
- 指ほぐし：{ins or "なし"} は受けた側の $ほぐし が2未満なら「〇〇の指ほぐし」に置き換わる。
- 回想バトル：「回想の栞」方式。敗北シナリオはマスターの @敗北_<経路>_<責め手>。

■ 直し方
tools の中で  python common/gen_v4.py .  →  python common/patch_recall_ui.py out\\{OUTN}\\Card {C}
（cfg.py 先頭の sys.path を tools\\common に書き換えてから）

■ 実機未確認の点
クエスト一覧の表示／受けた側ごとのスタックの積み上がりと6での処理／性別「その他」のカード／フェードアウト・SE の行
"""
open(os.path.join(DST, "README.txt"), "w", encoding="utf-8", newline="\r\n").write(readme)
print("packaged", DST, "images", len(imgs), "chars", total)
