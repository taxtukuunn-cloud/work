# N34 禁書庫の司書（Library）の設定（gen_v4.py 用）。登場人物は全員20歳以上。女性と男の娘の混合。
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/home/claude/n3x/common")
from cfgkit import T, std_magic

S = "綴じ頁"
CFG = dict(
    code="Library", outdir="N34_Library_MOD", stack=S, sex="女", speaker_sex="女", attr="闇属性",
    bg="#Library/Library_bg.png",
    quest_name="禁書庫の司書（司書長　ヘレナ）", quest_name_kaisou="禁書庫の司書【回想バトル】",
    lose_title="―― 禁書庫の司書　特別室の蔵書 ――",
    player_full_desc="綴じ頁、十二枚。……最後の頁が綴じられた。僕はもう、この書庫の棚に並ぶ一冊の本だ。",
    conv_desc="男モンスターの背に蔵書印が押され、蔵書として書庫の側へ移った。",
    magic_conv="綴じ頁、六枚。……製本完了。同伴者さんは本日付けで当館の蔵書です。",
    speakers=[("%ヘレナ", "master", "女"), ("%ルカ", "e1", "女"), ("%リーフ", "e2", "女"), ("%セージ", "e3", "女"), ("%オルガ", "boss", "女")],
    weak={"m1": "耳責め", "m2": "乳首責め", "m3": "本番", "e1": "乳首責め", "e2": "本番", "e3": "本番", "boss": "魔法責め"},
    master=dict(
        name="司書長　ヘレナ", race="魔術師", sex="女", atk=500,
        explain=f"★得意技【朗読】（読み上げた言葉が体に書き込まれる常識改変）で受けた相手の【{S}】+3（主人公は12枚で蔵書＝敗北／男モンスターは6枚で蔵書として敵側へ）。{S}は主人公とモンスターが別々に持つ。【羽ペンの先で】は乳首責め。【閉架の奥で】（口づけ＋ペニバン）は指で2回ほぐした後にだけ出せる。ターン終了時、主人公の{S}の段階に応じて 洗脳／洗脳／魔法使用不能／魔法使用不能＋500。",
        techs=[T("朗読", "耳責め", fav=3), T("羽ペンの先で", "乳首責め"), T("閉架の奥で", "本番", insert=True)],
        turn_end_ops=[[("status_p", "洗脳", 1)], [("status_p", "洗脳", 1)], [("status_p", "魔法使用不能", 1)],
                      [("status_p", "魔法使用不能", 1), ("dmg_p", 500)]]),
    mons={
        "e1": dict(name="見習い司書　ルカ", aid=4, lv=4, atk=450, hp=1400, rare="R", race="魔術師", sex="その他",
                   techs=[T("栞紐の", "乳首責め", fav=2), T("返却期限の囁き", "耳責め", st=("洗脳", 1))],
                   explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+1。★得意技【栞紐の】（栞紐を乳首に結んで引く）で受けた相手の{S}+2。【返却期限の囁き】で洗脳1ターン。",
                   summon_ops=[("add", 1)]),
        "e2": dict(name="写本師　リーフ", aid=5, lv=4, atk=550, hp=1500, rare="R", race="魔術師", sex="女",
                   techs=[T("製本の糊", "本番", fav=2), T("墨の口づけ", "キス", eff="&&キスエフェクト")],
                   explain=f"★得意技【製本の糊】（糊のようなゼリーをお尻へ。指でほぐしてから）で受けた相手の{S}+2。【墨の口づけ】は口づけ。自分のターン終了時：男モンスター1体に発情1ターン。",
                   end_ops=[("status_m_only", "発情", 1)]),
        "e3": dict(name="修復係　セージ", aid=6, lv=4, atk=500, hp=1600, rare="R", race="魔術師", sex="その他",
                   techs=[T("修復の指", "本番", fav=2, finger=True), T("綴じ紐で", "魔法責め", st=("寸止め", 1))],
                   explain=f"召喚時：主人公に魔法使用不能1ターン。★得意技【修復の指】（指で前立腺の「傷み」を点検する）で受けた相手の{S}+2。【綴じ紐で】（綴じ紐の貞操帯）で寸止め1ターン。",
                   summon_ops=[("status_p", "魔法使用不能", 1)]),
        "boss": dict(name="館長　オルガ", aid=7, lv=7, atk=1200, hp=6000, rare="SR", race="魔術師", sex="女",
                     techs=[T("蔵書印", "魔法責め", fav=3), T("製本の儀", "本番", insert=True, st=("寸止め", 1))],
                     explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+3。★得意技【蔵書印】（言葉で頭を、指で乳首を同時に）で受けた相手の{S}+3。【製本の儀】（ペニバン。指で2回ほぐした後だけ）で寸止め1ターン。固有効果【蔵書登録】自分のターン終了時、主人公の{S}が9以上なら1試合1回、男モンスター1体を蔵書として敵側へ。",
                     summon_ops=[("add", 3)],
                     unique=dict(name="蔵書登録", min=9, once=True, ops=[("m_status_add", "魔法使用不能", 1, 6)])),
    },
    magic=std_magic(S, [("延滞の督促", "add", 2), ("静粛に", "trap", "攻撃不能"), ("禁書の頁", "target", ("洗脳", 1)),
                        ("蔵書検索", "search", None), ("閉館時間", "persist", None)]),
)
