# N32 アラクネの古城（Arachne）の設定（gen_v4.py 用）。登場人物は全員20歳以上。女性（アラクネ）と男の娘（蜘蛛）の混合。
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/home/claude/n3x/common")
from cfgkit import T, std_magic

S = "絡み糸"
CFG = dict(
    code="Arachne", outdir="N32_Arachne_MOD", stack=S, sex="女", speaker_sex="女", attr="闇属性",
    bg="#Arachne/Arachne_bg.png", mon_fate="destroy",
    quest_name="アラクネの古城（蜘蛛の女王　アラーネ）", quest_name_kaisou="アラクネの古城【回想バトル】",
    lose_title="―― アラクネの古城　白い繭 ――",
    player_full_desc="絡み糸、十二本。……最後の一本が巻かれ、僕は白い繭になった。糸の外の音は、もう聞こえない。",
    conv_desc="男モンスターは糸に巻かれて白い繭になり、巣の奥へ運ばれていった。",
    magic_conv="絡み糸、六本。……可愛い獲物がひとつ、繭になりました。巣の奥へ運んでおきなさい。",
    speakers=[("%アラーネ", "master", "女"), ("%シルク", "e1", "女"), ("%ベラ", "e2", "女"), ("%ヨル", "e3", "女"), ("%ネフィラ", "boss", "女")],
    weak={"m1": "魔法責め", "m2": "触手", "m3": "本番", "e1": "触手", "e2": "キス", "e3": "本番", "boss": "触手"},
    master=dict(
        name="蜘蛛の女王　アラーネ", race="昆虫", sex="女", atk=500,
        explain=f"★得意技【繭紡ぎ】（糸束を触手のように操り、お尻を開く）で受けた相手の【{S}】+3（主人公は12本で繭＝敗北／男モンスターは6本で繭にされ破壊）。{S}は主人公とモンスターが別々に持つ。【媚毒の牙】は触れずに頭で達させる。【吊るして貫く】（糸で乳首＋ふたなり逆アナル）は指で2回ほぐした後にだけ出せる。ターン終了時、主人公の{S}の段階に応じて 拘束／拘束／麻痺／麻痺＋500。",
        techs=[T("媚毒の牙", "魔法責め"), T("繭紡ぎ", "触手", fav=3), T("吊るして貫く", "本番", insert=True)],
        turn_end_ops=[[("status_p", "拘束", 1)], [("status_p", "拘束", 1)], [("status_p", "麻痺", 1)],
                      [("status_p", "麻痺", 1), ("dmg_p", 500)]]),
    mons={
        "e1": dict(name="糸紡ぎ　シルク", aid=4, lv=4, atk=500, hp=1400, rare="R", race="昆虫", sex="その他",
                   techs=[T("細い糸", "触手", fav=2), T("糸巻きの指", "乳首責め")],
                   explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+1。★得意技【細い糸】（細い糸を尿道から内側へ）で受けた相手の{S}+2。【糸巻きの指】は糸を巻く指で乳首を転がす。",
                   summon_ops=[("add", 1)]),
        "e2": dict(name="毒蜘蛛　ベラ", aid=5, lv=4, atk=550, hp=1500, rare="R", race="昆虫", sex="女",
                   techs=[T("媚毒の口づけ", "キス", fav=2, eff="&&キスエフェクト"), T("脚先で", "足コキ")],
                   explain=f"召喚時：男モンスター1体に麻痺1ターン。★得意技【媚毒の口づけ】で受けた相手の{S}+2。【脚先で】は蜘蛛の脚先で踏む。",
                   summon_ops=[("status_m_only", "麻痺", 1)]),
        "e3": dict(name="巣守り　ヨル", aid=6, lv=4, atk=450, hp=1600, rare="R", race="昆虫", sex="その他",
                   techs=[T("糸玉の", "本番", fav=2), T("巣の揺れ", "耳責め", st=("魅了", 1))],
                   explain=f"★得意技【糸玉の】（糸を巻いた珠を一粒ずつ。指でほぐしてから）で受けた相手の{S}+2。【巣の揺れ】で魅了1ターン。自分のターン終了時：男モンスター1体に拘束1ターン。",
                   end_ops=[("status_m_only", "拘束", 1)]),
        "boss": dict(name="繭の母　ネフィラ", aid=7, lv=7, atk=1200, hp=6000, rare="SR", race="昆虫", sex="女",
                     techs=[T("繭の中で", "触手", fav=3), T("母の交わり", "本番", insert=True, st=("寸止め", 1))],
                     explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+3。★得意技【繭の中で】（糸束でお尻を開きながら乳首を舐める）で受けた相手の{S}+3。【母の交わり】（ふたなり逆アナル。指で2回ほぐした後だけ）で寸止め1ターン。固有効果【繭包み】自分のターン終了時、主人公の{S}が6以上なら、男モンスター1体に拘束1ターンと{S}+2。",
                     summon_ops=[("add", 3)],
                     unique=dict(name="繭包み", min=6, once=False, ops=[("m_status_add", "拘束", 1, 2)])),
    },
    magic=std_magic(S, [("媚毒の滴", "add", 2), ("粘つく糸", "trap", "拘束"), ("月夜の吊り籠", "target", ("拘束", 2)),
                        ("子蜘蛛の群れ", "search", None), ("蜘蛛の巣", "persist", None)]),
)
