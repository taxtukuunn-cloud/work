#!/usr/bin/env python3
"""N23 足の女王様（Heels）v4 カード一式の生成スクリプト。
入力: scen/<経路>_<key>.txt（#導入/#プレイ/#結び の3区画）, lines/<key>.json（v4）
出力: out/N23_Heels_MOD/Card/*.txt, EventList/Quest/Heels.txt （UTF-8・CRLF）
v4の決まり：得意技だけが服従度を積む／受けた側が個別に持つ（主人公12・男モンスター6）／
段階は受けた側のスタック／挿入技はほぐし2未満なら指ほぐし／クエスト＋回想バトル。
"""
import os, re, json

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCEN = os.path.join(BASE, "scen")
LINES = os.path.join(BASE, "lines")
OUT = os.path.join(BASE, "out", "N23_Heels_MOD")
C = "Heels"
P = f"#{C}/{C}_"
ST = "$服従度"
HG = "$ほぐし"
PMAX, MMAX = 12, 6

ROUTES = [("btl", 1), ("onani", 2), ("inochi", 3), ("onedari", 4)]
ATTACKERS = [("m1", 1), ("m2", 2), ("m3", 3), ("e1", 4), ("e2", 5), ("e3", 6), ("boss", 7)]
AID = dict(ATTACKERS)
# 敗北後の弱点＝その責め手の得意技の攻撃タイプ
WEAK = {"m1": "足コキ", "m2": "足コキ", "m3": "足コキ", "e1": "魔法責め", "e2": "耳責め", "e3": "キス", "boss": "本番"}
SPEAKERS = [("%クラウディア", "master"), ("%ミナ", "e1"), ("%ザラ", "e2"), ("%リタ", "e3"), ("%アウグスタ", "boss")]


def J(key):
    return json.load(open(os.path.join(LINES, f"{key}.json"), encoding="utf-8"))


def ind(lines, n=1):
    return [(" " * n) + l if l else l for l in lines]


def block(cond, body):
    return [f"if,{cond}", "{"] + ind(body) + ["}"]


def ifelse(cond, a, b):
    return [f"if,{cond}", "{"] + ind(a) + ["}else{"] + ind(b) + ["}"]


def staged(arr):
    out = []
    for i, s in enumerate(arr):
        out += block(f"$段階,==,{i+1}", [f"セリフ,{s}"])
    return out


# ------------------------------------------------------------ スタック
def target_calc():
    """$対象（0=主人公／1=男モンスター）、$値、$ほぐし値、$段階 を決める"""
    p = ["$対象,=,0", f"$値,=,相手プレイヤー.{ST}", f"$ほぐし値,=,相手プレイヤー.{HG}", "$段階,=,1"]
    p += block("$値,>=,4", ["$段階,=,2"]) + block("$値,>=,7", ["$段階,=,3"]) + block("$値,>=,10", ["$段階,=,4"])
    m = ["$対象,=,1", f"$値,=,相手.{ST}", f"$ほぐし値,=,相手.{HG}", "$段階,=,1"]
    m += block("$値,>=,2", ["$段階,=,2"]) + block("$値,>=,4", ["$段階,=,3"]) + block("$値,>=,5", ["$段階,=,4"])
    return ifelse("相手,==,相手プレイヤー", p, m)


def add_player(n, finish):
    b = [f"相手プレイヤー.{ST},+=,{n}", f"$表示用,=,相手プレイヤー.{ST}", f"説明,（あなたの服従度 {{$表示用}}／{PMAX}）"]
    b += block(f"相手プレイヤー.{ST},>=,{PMAX}", ["話者,自分", f"セリフ,{finish}", "とどめダメージ,相手プレイヤー,9999"])
    return b


def add_monster(n):
    b = [f"相手.{ST},+=,{n}", f"$表示用,=,相手.{ST}", f"説明,（男モンスターの服従度 {{$表示用}}／{MMAX}）"]
    b += block(f"相手.{ST},>=,{MMAX}", ["$変換,=,1"])
    return b


def add_rule(n, finish, conv):
    """魔法・罠・召喚時の +n：男モンスターがいればランダムに1体、いなければ主人公"""
    mon = ["カードランダム抜き出し,相手モンスター,1,%対象", f"%対象.{ST},+=,{n}", f"$表示用,=,%対象.{ST}",
           f"説明,（男モンスターの服従度 {{$表示用}}／{MMAX}）"]
    mon += block(f"%対象.{ST},>=,{MMAX}", [f"セリフ,{conv}", "説明,男モンスターは女王の足置き台として敵側へ移った。",
                                           "コントロール変更,%対象,自分所属"])
    pl = [f"相手プレイヤー.{ST},+=,{n}", f"$表示用,=,相手プレイヤー.{ST}", f"説明,（あなたの服従度 {{$表示用}}／{PMAX}）"]
    pl += block(f"相手プレイヤー.{ST},>=,{PMAX}", [f"セリフ,{finish}", "とどめダメージ,相手プレイヤー,9999"])
    return ifelse("相手モンスター.Count,>,0", mon, pl)


FINISH = None  # m1.json の finish


def tech_block(t, atype, cg, aid, gain=0, josou=False, insert=False, extra=None, effect="&&セクシーエフェクト"):
    """1つの技。gain>0 なら得意技（受けた側に+gain）。josou＝男モンスターに当たれば女装娘。
    insert＝挿入技（ほぐし2未満なら指ほぐし）。extra＝当たった時の追加処理"""
    def lines_for(tt):
        b = ["話者,自分", f"技名表示,{tt['name']}", f"画像,{cg},1"]
        b += ifelse("$対象,==,0", staged(tt["atk_p"]), staged(tt["atk_m"]))
        b += ["話者,相手"] + ifelse("$対象,==,0", staged(tt["rx_p"]), staged(tt["rx_m"]))
        return b + ["話者,自分", f"攻撃エフェクト変更,{effect}"]

    main = lines_for(t)
    main += block("$対象,==,0", [f"$$Heels_最後の責め手,=,{aid}"])
    if gain:
        on_m = ["$変換,=,2"] if josou else add_monster(gain)
        main += ifelse("$対象,==,0", add_player(gain, FINISH), on_m)
    elif josou:
        main += block("$対象,==,1", ["$変換,=,2"])
    if extra:
        main += extra
    if insert:
        h = t["hogushi"]
        hb = ["話者,自分", f"技名表示,{h['name']}", f"画像,{cg},1"]
        hb += ifelse("$対象,==,0",
                     ifelse("$ほぐし値,==,0", [f"セリフ,{h['atk_p'][0]}"], [f"セリフ,{h['atk_p'][1]}"]),
                     ifelse("$ほぐし値,==,0", [f"セリフ,{h['atk_m'][0]}"], [f"セリフ,{h['atk_m'][1]}"]))
        hb += ["話者,相手"] + ifelse("$対象,==,0",
                                    ifelse("$ほぐし値,==,0", [f"セリフ,{h['rx_p'][0]}"], [f"セリフ,{h['rx_p'][1]}"]),
                                    ifelse("$ほぐし値,==,0", [f"セリフ,{h['rx_m'][0]}"], [f"セリフ,{h['rx_m'][1]}"]))
        hb += ["話者,自分"]
        hb += ifelse("$対象,==,0",
                     [f"$$Heels_最後の責め手,=,{aid}", f"相手プレイヤー.{HG},+=,1", f"$表示用,=,相手プレイヤー.{HG}",
                      "説明,（ほぐし {$表示用}／2）"],
                     [f"相手.{HG},+=,1", f"$表示用,=,相手.{HG}", "説明,（男モンスターのほぐし {$表示用}／2）"])
        if gain:  # 得意技が挿入技のキャラは指ほぐしでも+1
            hb += ifelse("$対象,==,0", add_player(1, FINISH), add_monster(1))
        body = ifelse("$ほぐし値,<,2", hb, main)
    else:
        body = main
    return block(f"攻撃タイプ,==,{atype}", body)


def battle_section(types, techs):
    out = ["@戦闘", "攻撃タイプランダム変更," + ",".join(types), "$変換,=,0"] + target_calc()
    for t in techs:
        out += t
    return out + [""]


def after_battle(conv, conv_rx, josou=None, josou_rx=None):
    b = ["@戦闘後"]
    b += block("$変換,==,1", ["話者,自分", f"セリフ,{conv}", "話者,相手", f"セリフ,{conv_rx}",
                              "説明,男モンスターは女王の足置き台として敵側へ移った。", "コントロール変更,相手,自分所属"])
    j = josou or "侍女のドレスがよく似合うわ。今日からあなたも侍女ね。"
    jr = josou_rx or "な、なんだこの格好は……俺が……侍女……？"
    b += block("$変換,==,2", ["話者,自分", f"セリフ,{j}", "話者,相手", f"セリフ,{jr}",
                              "説明,ストッキングと侍女のドレスを着せられた男モンスターは、戦う力を失い「侍女にされた男」になった。"] +
               josou_cmds("相手"))
    b += ["$変換,=,0", ""]
    return b


def josou_cmds(target):
    """女装娘：対象を破壊扱いにし、主人公側へ Heels_josou を特殊召喚（未検証の書き方）"""
    return [f"効果破壊,{target}", "&女装ID,=,Heels_josou", "効果生成デッキ内,&女装ID,味方",
            "%女装娘,=,自分デッキ.?ID:&女装ID", "特殊召喚,%女装娘,相手所属"]


def street_hooks(sections):
    out = []
    for s in sections:
        out += [f"@{s}_街バトル", f"    イベント実行,{s}", ""]
    return out


# ------------------------------------------------------------ シナリオ
def read_scen(route, key):
    lines = [l.rstrip("\r\n") for l in open(os.path.join(SCEN, f"{route}_{key}.txt"), encoding="utf-8-sig")]
    return [l for l in lines if l.strip() and not l.startswith("#")]


def scen_section(route, key):
    body = read_scen(route, key)
    return [f"@敗北_{route}_{key}"] + ind(body, 4) + [
        "    フラッシュ,白",
        "    説明,―― 会員制サロン ルージュ・ソール　女王の侍女　登録完了 ――",
        f"    主人公攻撃タイプ弱点付与,{WEAK[key]},50",
        ""]


def dispatch():
    out = [f"話者生成,{v},{P}{img}.png,女" for v, img in SPEAKERS]
    for key, aid in ATTACKERS:
        inner = []
        for r, rid in ROUTES:
            inner += block(f"$経路,==,{rid}", [f"イベント実行,敗北_{r}_{key}"])
        out += block(f"$責め手,==,{aid}", inner)
    return out


# ------------------------------------------------------------ 後処理
_IMG = re.compile(r"^(\s*)画像,(#[^,]+),(.*)$")
_SPK = re.compile(r"^(\s*)話者生成,(%[^,]+),(#[^,]+),(.*)$")
_VAR = re.compile(r"^(\s*)(&[^,]+),(#[^,]+)$")


def var_images(lines):
    """# 画像を @初期設定 の & 変数に置き換える（実機で直接パスは出なかった）"""
    defs, out = {}, []

    def var(path):
        name = "&画像_" + os.path.splitext(os.path.basename(path))[0]
        defs[name] = path
        return name
    for l in lines:
        m = _IMG.match(l)
        if m:
            sp, path, rest = m.groups()
            out.append(f"{sp}画像,{var(path)},{rest}")
            continue
        m = _SPK.match(l)
        if m:
            sp, v, path, rest = m.groups()
            out.append(f"{sp}話者生成,{v},{var(path)},{rest}")
            continue
        out.append(l)
    if defs:
        i = out.index("@初期設定") + 1
        out[i:i] = [f"    {k},{p}" for k, p in sorted(defs.items())]
    return out


IMAGES = set()


def write(rel, lines):
    lines = var_images(lines)
    for l in lines:
        m = re.search(r"#Heels/([^,]+\.png)", l)
        if m:
            IMAGES.add(m.group(1))
    path = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(["default"] + lines) + "\r\n")


def common_init(name, img, lv, atk, hp, typ, rare, explain, flavor, sex="女"):
    return ["@初期設定", f"    &カード名,{name}", f"    &カード画像,{img}",
            f"    レベル設定,{lv}", f"    攻撃力設定,{atk}", f"    最大HP設定,{hp}",
            "    属性設定,闇属性", f"    タイプ設定,{typ}", f"    性別設定,{sex}", f"    レアリティ設定,{rare}",
            "    攻撃エフェクト設定,&&セクシーエフェクト",
            f"    効果設定,1,explain,{explain}" if explain else None,
            f"    効果設定,0,explain,{flavor}"]


# ------------------------------------------------------------ マスター
DECK = [f"{C}_mons_e1"] * 3 + [f"{C}_mons_e2"] * 3 + [f"{C}_mons_e3"] * 3 + [f"{C}_mons_boss"] + \
       [f"{C}_magic_{i}" for i in range(1, 6) for _ in range(2)]


def lose_play(record):
    b = ["BGM,&&敗北BGM", "$経路,=,$$Heels_敗北経路"] + block("$経路,==,0", ["$経路,=,1"]) + \
        block("死亡理由,==,オナニー", ["$経路,=,2"]) + ["$責め手,=,$$Heels_最後の責め手"] + \
        block("$責め手,==,0", ["$責め手,=,1"]) + ["イベント実行,敗北再生"]
    if record:
        b += ["$$Heels_敗北回数,+=,1", "$$Heels_前回敗北経路,=,$経路", "$$Heels_前回最後の責め手,=,$責め手"]
    return b + ["説明,GAME OVER"]


def reset_globals():
    return ["$$Heels_最後の責め手,=,1", "$$Heels_敗北経路,=,0"]


def master():
    global FINISH
    m1, m2, m3 = J("m1"), J("m2"), J("m3")
    FINISH = m1["finish"]
    L = [x for x in common_init(
        "女王様 クラウディア", f"{P}master.png", 8, 1000, 10000, "悪魔", "UR",
        f"★得意技【ハイヒールの足】で攻撃を受けた者の【服従度】+3（主人公と男モンスターが別々に持つ。減らない）。主人公は{PMAX}で完全服従（敗北）。男モンスターは{MMAX}で足置き台として敵側へ。【侍女のドレス】を受けた男モンスターは即「侍女にされた男」になる。【ヒールで乳首を踏みながら】は相手のほぐしが2未満なら指ほぐし。ターン終了時：主人公の服従度に応じて見惚れ（1〜6）・攻撃不能（7〜11）。",
        m1["flavor"]) if x]
    L += [f"    &技CG_1,{P}atk_m1.png", f"    &技CG_2,{P}atk_m2.png", f"    &技CG_3,{P}atk_m3.png",
          f"    &背景,{P}bg.png", ""]

    # --- クエストイベント
    f = m1["first"]
    first = ["背景,&背景", f"説明,{f[0]}", f"説明,{f[1]}", "画像,&カード画像,1",
             f"セリフ,{f[2]}", f"セリフ,{f[3]}", f"セリフ,{f[4]}"]
    won = ["画像,&カード画像,1"] + [f"セリフ,{s}" for s in m1["won"]]
    prev = ["画像,&カード画像,1"]
    for i, s in enumerate(m1["prev"]):
        prev += block(f"$$Heels_前回敗北経路,==,{i+1}", [f"セリフ,{s}"])
    prev += ["アラート,前回の続きから始めますか？", "選択肢生成,勝負する,誘いに乗る（前回の続き）,引き返す"]
    prev += block("選択肢,==,2", [f"セリフ,{m1['continue']}", "イベント実行,前回続き", "イベント終了"])
    prev += block("選択肢,==,3", [f"セリフ,{m1['decline']}", "イベント終了"])
    qe = ["@クエストイベント", "話者,自分"]
    qe += ifelse("$$Heels_敗北回数,==,0", ifelse("$$Heels_挑戦回数,==,0", first, won),
                 ifelse("is前回プレイヤー勝利,==,true", won, prev))
    qe += ["$$Heels_回想バトル,=,0", "$$Heels_挑戦回数,+=,1"] + reset_globals()
    qe += ["デッキ設定," + ",".join(DECK), "デッキ報酬設定,300,300,0", "バトル開始,&背景,&&戦闘BGM"]
    qe += ifelse("is敗北,==,true", lose_play(True),
                 ["BGM,&&戦闘BGM", "背景,&背景", "画像,&カード画像,1", "話者,自分", f"セリフ,{m1['win']}"]) + [""]
    L += qe

    # --- 回想バトル
    k = m1["kaisou"]
    kb = ["@回想バトル", "話者,自分", "背景,&背景", "画像,&カード画像,1", f"セリフ,{k['open']}",
          "$$Heels_回想バトル,=,1"] + reset_globals()
    kb += ["デッキ設定," + ",".join(DECK), "バトル開始,&背景,&&戦闘BGM"]
    kb += ifelse("is敗北,==,true", lose_play(False),
                 ["BGM,&&戦闘BGM", "背景,&背景", "画像,&カード画像,1", "話者,自分", f"セリフ,{m1['win']}"])
    kb += ["話者,自分", f"セリフ,{k['end']}", "$$Heels_回想バトル,=,0", ""]
    L += kb

    menu = ["@回想メニュー", "話者,自分", f"セリフ,{k['menu']}", "$続ける,=,1", "while,$続ける,==,1", "{"]
    inner = ["選択肢生成,デッキから選んで場に呼ばせる,デッキから選んで手札に加えさせる,カードを1枚引かせる,このまま進める"]
    inner += block("選択肢,==,1", ["%候補,=,自分デッキ.?isモンスター:true"] + ifelse(
        "%候補.Count,>,0", ["カード選択,%候補,1,1", f"セリフ,{k['summon']}", "特殊召喚,選択カード,味方"],
        ["説明,デッキにモンスターが残っていない。"]))
    inner += block("選択肢,==,2", ["%候補,=,自分デッキ"] + ifelse(
        "%候補.Count,>,0", ["カード選択,%候補,1,1", f"セリフ,{k['search']}", "効果サーチ,選択カード,自分所属"],
        ["説明,デッキにカードが残っていない。"]))
    inner += block("選択肢,==,3", [f"セリフ,{k['draw']}", "効果ドロー,自分プレイヤー"])
    inner += block("選択肢,==,4", [f"セリフ,{k['go']}", "$続ける,=,0"])
    menu += ind(inner) + ["}", ""]
    L += menu

    L += ["@試合開始", f"相手プレイヤー.{ST},=,0", f"相手プレイヤー.{HG},=,0", "話者,自分"] + \
         [f"セリフ,{s}" for s in m1["start"]] + block("$$Heels_回想バトル,==,1", ["イベント実行,回想メニュー"]) + [""]
    L += ["@ターン開始"] + block("$$Heels_回想バトル,==,1", ["イベント実行,回想メニュー"]) + [""]

    stage_p = [f"$値,=,相手プレイヤー.{ST}", "$段階,=,1"] + block("$値,>=,4", ["$段階,=,2"]) + \
              block("$値,>=,7", ["$段階,=,3"]) + block("$値,>=,10", ["$段階,=,4"])
    L += ["@召喚宣言"] + stage_p + ["話者,自分"] + staged(m1["summon"]) + [""]

    t1 = tech_block(m1["tech"], "足コキ", "&技CG_1", 1, gain=3)
    t2 = tech_block(m2["tech"], "魔法責め", "&技CG_2", 2, josou=True)
    t3 = tech_block(m3["tech"], "本番", "&技CG_3", 3, insert=True)
    L += battle_section(["足コキ", "魔法責め", "本番"], [t1, t2, t3])
    L += after_battle(m1["conv"], m1["conv_rx"], m2["josou"], m2["josou_rx"])

    te = ["@ターン終了宣言"] + stage_p + ["話者,自分"]
    eff = [("見惚れ", 1), ("見惚れ", 2), ("攻撃不能", 1), ("攻撃不能", 1)]
    for i, s in enumerate(m1["turnend"]):
        te += block(f"$段階,==,{i+1}", [f"セリフ,{s}", f"状態異常付与,相手プレイヤー,{eff[i][0]},{eff[i][1]}"])
    te = te[:len(stage_p) + 2] + block("$値,>=,1", te[len(stage_p) + 2:])  # 服従度0の間は何もしない
    te += block(f"相手プレイヤー.{ST},>=,{PMAX}", [f"セリフ,{FINISH}", "とどめダメージ,相手プレイヤー,9999"])
    L += te + [""]

    # おねだり
    L += ["@おねだり", "話者,自分", "画像,&カード画像,1", f"セリフ,{m1['onedari_open']}",
          f"選択肢生成,{m1['tech']['name']},{m2['tech']['name']},{m3['tech']['name'].replace('【同時】', '')}"]
    for i, (mm, at) in enumerate([(m1, "足コキ"), (m2, "魔法責め"), (m3, "本番")]):
        L += block(f"選択肢,==,{i+1}", ["話者,相手", f"セリフ,{mm['onedari']}", "話者,自分",
                                        "セリフ,……ええ。その口で言ったこと、忘れないわ。", f"攻撃タイプ固定,{at}",
                                        f"$$Heels_最後の責め手,=,{i+1}"])
    L += ["$$Heels_敗北経路,=,4", "状態異常付与,自分,弱点付与スキル,1", ""]
    L += ["@おねだり後", "攻撃タイプ固定解除", "状態異常解除,自分,弱点付与スキル"] + \
         block("相手プレイヤー.HP,>,0", ["$$Heels_敗北経路,=,0"]) + [""]

    # 命乞い
    ino = ["@命乞い", "話者,自分", "画像,&カード画像,1"]
    ino += ifelse("命乞い回数,>=,2", [f"セリフ,{s}" for s in m1["inochi2"]], [f"セリフ,{s}" for s in m1["inochi"]])
    ino += ["選択肢生成,とどめを刺す,手を止める"]
    ino += block("選択肢,==,1", [f"セリフ,{m1['inochi_fail']}", "命乞い失敗", "イベント終了"])
    ino += block("$$Heels_最後の責め手,>,3", ["$$Heels_最後の責め手,=,1"])
    ino += ["$$Heels_敗北経路,=,3", "説明,赤い靴底が目に入った一瞬、とどめのカードを出す手が止まった。",
            f"セリフ,{m1['inochi_trap']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ino

    # オナニー（得意技＝ヒールに合わせた自慰）
    o = m1["onani"]
    ona = ["@オナニー", f"画像,{P}onanie_master.png,1", "フェードイン,1", "$$Heels_敗北経路,=,2"]
    ona += block("$$Heels_最後の責め手,>,3", ["$$Heels_最後の責め手,=,1"])
    ona += [f"説明,{o['desc'][0]}", f"説明,{o['desc'][1]}", "話者,自分"]
    ona += ifelse("オナニー回数,>=,2", [f"セリフ,{s}" for s in o["atk2"]], [f"セリフ,{s}" for s in o["atk"]])
    ona += ["話者,相手", f"セリフ,{o['rx']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ona

    L += ["@終了時一言", "話者,自分", f"セリフ,{m1['end']}", ""]
    L += ["@敗北再生", "背景,&背景", "画像,&カード画像,1", "フェードイン,1"] + dispatch() + [""]
    L += ["@前回続き", "$経路,=,$$Heels_前回敗北経路", "$責め手,=,$$Heels_前回最後の責め手"] + \
         block("$経路,==,0", ["$経路,=,1"]) + block("$責め手,==,0", ["$責め手,=,1"]) + \
         ["BGM,&&敗北BGM", "イベント実行,敗北再生", "$$Heels_敗北回数,+=,1", "説明,GAME OVER", ""]
    for r, _ in ROUTES:
        for a, _ in ATTACKERS:
            L += scen_section(r, a)
    L += street_hooks(["戦闘", "戦闘後", "オナニー", "おねだり", "おねだり後", "命乞い", "終了時一言"])
    write(f"Card/{C}_master.txt", L)


# ------------------------------------------------------------ モンスター
MONS = {
    "e1": dict(name="ストッキングの侍女 ミナ", lv=4, atk=1100, hp=1500, rare="R", types=["魔法責め", "足コキ"], star=0, gain=2,
               explain="★得意技【ストッキングを穿かせる】：主人公の服従度+2。男モンスターが受けると即「侍女にされた男」に。召喚時：服従度+1（男モンスターがいればそのうち1体、いなければ主人公）。【足裏で】を受けた者は見惚れ1ターン。"),
    "e2": dict(name="調教師 ザラ", lv=4, atk=1300, hp=1400, rare="R", types=["耳責め", "乳首責め"], star=0, gain=2,
               explain="★得意技【命令の言葉】：受けた者の服従度+2。召喚時：男モンスター1体に攻撃指示不能1ターン。"),
    "e3": dict(name="奉仕係 リタ", lv=4, atk=1200, hp=1600, rare="R", types=["キス", "本番"], star=0, gain=2,
               explain="★得意技【女王の命令で】：受けた者の服従度+2、魅了1ターン。自分のターン終了時：服従度+1（男モンスターがいればそのうち1体、いなければ主人公）。"),
    "boss": dict(name="女帝 アウグスタ", lv=7, atk=2400, hp=3200, rare="SR", types=["耳責め", "本番"], star=1, gain=3,
                 explain="★得意技【侍女に胸を舐めさせながら】：受けた者の服従度+3（ほぐし2未満なら指ほぐし＝ほぐし+1・服従度+1）。【男は跪くもの】を受けた者は見惚れ1ターン。召喚時：服従度+3。固有効果【足置き】：主人公の服従度6以上なら、自分のターン終了時に男モンスター1体を攻撃不能2ターン。"),
}


def monster(key):
    m, d = MONS[key], J(key)
    aid = AID[key]
    img = f"{P}{key}.png"
    L = [x for x in common_init(m["name"], img, m["lv"], m["atk"], m["hp"], "悪魔", m["rare"], None, d["flavor"]) if x]
    L += [f"    &技CG,{P}atk_{key}.png",
          f"    効果設定,1,forceTrigger,{m['explain']}", "    誘発効果設定,1,場に出た時",
          "    効果条件設定,1,トリガー受動カード,==,自分"]
    if key in ("e3", "boss"):
        L += ["    効果設定,2,forceTrigger,自分のターン終了時に発動する効果。", "    誘発効果設定,2,エンドフェイズ開始時",
              "    効果条件設定,2,Now自分ターン,==,true"]
    L += [""]

    ef = ["@効果", "switch,効果ID", "case,1", "{", "    話者,自分", f"    画像,{img},1"]
    ef += [f"    セリフ,{s}" for s in d["summon"]]
    if d.get("summon_effect"):
        ef += [f"    セリフ,{d['summon_effect']}"]
    if key == "e1":
        ef += ind(add_rule(1, FINISH, d["conv"]), 4)
    if key == "boss":
        ef += ind(add_rule(3, FINISH, d["conv"]), 4)
    if key == "e2":
        ef += ind(block("相手モンスター.Count,>,0", ["カードランダム抜き出し,相手モンスター,1,%対象",
                                                   "状態異常付与,%対象,攻撃指示不能,1"]), 4)
    ef += ["}"]
    if key == "e3":
        ef += ["case,2", "{", "    話者,自分", f"    セリフ,{d['turnend']}"] + ind(add_rule(1, FINISH, d["conv"]), 4) + ["}"]
    if key == "boss":
        body = ["話者,自分", f"セリフ,{d['turnend']}", "説明,【足置き】男モンスター1体が女帝の足置きにされ、攻撃できない。",
                "カードランダム抜き出し,相手モンスター,1,%対象", "状態異常付与,%対象,攻撃不能,2"]
        ef += ["case,2", "{"] + ind(block(f"相手プレイヤー.{ST},>=,6", block("相手モンスター.Count,>,0", body)), 4) + ["}"]
    ef += ["endswitch", ""]
    L += ef

    t1, t2 = d["techs"]
    techs = []
    if key == "e1":
        techs.append(tech_block(t1, "魔法責め", "&技CG", aid, gain=2, josou=True))
        techs.append(tech_block(t2, "足コキ", "&技CG", aid, extra=["状態異常付与,相手,見惚れ,1"]))
    elif key == "e2":
        techs.append(tech_block(t1, "耳責め", "&技CG", aid, gain=2))
        techs.append(tech_block(t2, "乳首責め", "&技CG", aid))
    elif key == "e3":
        techs.append(tech_block(t1, "キス", "&技CG", aid, gain=2, extra=["状態異常付与,相手,魅了,1"], effect="&&キスエフェクト"))
        techs.append(tech_block(t2, "本番", "&技CG", aid))
    else:
        techs.append(tech_block(t1, "耳責め", "&技CG", aid, extra=["状態異常付与,相手,見惚れ,1"]))
        techs.append(tech_block(t2, "本番", "&技CG", aid, gain=3, insert=True))
    L += battle_section(m["types"], techs)
    L += after_battle(d["conv"], d["conv_rx"], d["josou"] or None)

    L += ["@おねだり", "話者,自分", "画像,&カード画像,1", f"セリフ,{d['onedari_open']}",
          f"選択肢生成,{t1['name'].replace('【同時】', '')},{t2['name'].replace('【同時】', '')}"]
    for i in range(2):
        L += block(f"選択肢,==,{i+1}", ["話者,相手", f"セリフ,{d['onedari'][i]}", "話者,自分", "セリフ,……承りました。",
                                        f"攻撃タイプ固定,{m['types'][i]}"])
    L += [f"$$Heels_最後の責め手,=,{aid}", "$$Heels_敗北経路,=,4", "状態異常付与,自分,弱点付与スキル,1", ""]
    L += ["@おねだり後", "攻撃タイプ固定解除", "状態異常解除,自分,弱点付与スキル"] + \
         block("相手プレイヤー.HP,>,0", ["$$Heels_敗北経路,=,0"]) + [""]

    ino = ["@命乞い", "話者,自分", "画像,&カード画像,1"] + [f"セリフ,{s}" for s in d["inochi"]]
    ino += ["選択肢生成,とどめを刺す,手を止める"]
    ino += block("選択肢,==,1", ["セリフ,……そう。", "命乞い失敗", "イベント終了"])
    ino += [f"$$Heels_最後の責め手,=,{aid}", "$$Heels_敗北経路,=,3",
            "説明,とどめの一撃を出すはずの手が、ほんの一瞬止まった。",
            f"セリフ,{d['inochi_trap']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ino

    o = d["onani"]
    ona = ["@オナニー", f"画像,{P}onanie_{key}.png,1", "フェードイン,1",
           f"$$Heels_最後の責め手,=,{aid}", "$$Heels_敗北経路,=,2",
           f"説明,{o['desc'][0]}", f"説明,{o['desc'][1]}", "話者,自分"] + [f"セリフ,{s}" for s in o["atk"]]
    ona += ["話者,相手", f"セリフ,{o['rx']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ona
    L += ["@終了時一言", "話者,自分", f"セリフ,{d['end']}", ""]
    L += ["@敗北後"] + block("is敗北,==,false", ["話者,自分", f"セリフ,{d['win']}"]) + [""]
    L += street_hooks(["戦闘", "戦闘後", "オナニー", "おねだり", "おねだり後", "命乞い", "終了時一言", "効果"])
    write(f"Card/{C}_mons_{key}.txt", L)


# ------------------------------------------------------------ 女装娘
def josou_card():
    L = [x for x in common_init(
        "侍女にされた男", f"{P}josou.png", 2, 500, 1500, "戦士", "N",
        "侍女のドレスを着せられた男モンスター。攻撃は通常攻撃のみ。場にいる間、相手（女王側）のターン終了時に主人公の服従度+1。",
        "黒い膝上丈のドレスに白いエプロン、ガーターで留めた黒いストッキング。裾を押さえてうつむいたまま、女王の足元へ視線が吸い寄せられていく。",
        sex="男") if x]
    L += ["    効果設定,1,forceTrigger,相手のターン終了時：主人公の服従度+1。", "    誘発効果設定,1,エンドフェイズ開始時",
          "    効果条件設定,1,Now自分ターン,==,false", ""]
    body = ["話者,自分", "セリフ,……スカートの中が、すうすうする……女王様の足音が……頭から離れない……",
            f"自分プレイヤー.{ST},+=,1", f"$表示用,=,自分プレイヤー.{ST}", f"説明,（あなたの服従度 {{$表示用}}／{PMAX}）"]
    body += block(f"自分プレイヤー.{ST},>=,{PMAX}", ["とどめダメージ,自分プレイヤー,9999"])
    L += ["@効果", "switch,効果ID", "case,1", "{"] + ind(body, 4) + ["}", "endswitch", ""]
    L += ["@戦闘", "攻撃タイプ変更,通常攻撃", "話者,自分", "セリフ,こ、こんな格好で……戦えって……？", ""]
    L += street_hooks(["戦闘", "効果"])
    write(f"Card/{C}_josou.txt", L)


# ------------------------------------------------------------ 魔法・罠
def magic_all():
    m1, e1 = J("m1"), J("e1")
    conv = m1["conv"]
    MAG = [
        dict(no=1, name="跪きなさい", type="通常魔法", rare="R",
             explain="服従度+2（男モンスターがいればそのうち1体、いなければ主人公）。",
             flavor="女王が指先ひとつで床を示す。その仕草だけで、膝が勝手に赤い絨毯へ落ちていく。",
             lines=["跪きなさい。……そう、その高さがあなたの目線よ。"], body=add_rule(2, None, conv)),
        dict(no=2, name="侍女の衣装", type="通常魔法", rare="SR",
             explain="相手の男モンスター1体を選び、侍女のドレスを着せる。そのモンスターは即「侍女にされた男」になる（主人公側に残る）。",
             flavor="黒い膝上丈のドレス、白い襟とエプロン、ガーターで留める黒いストッキング。サロンの侍女は皆これを着る。",
             target="効果ターゲット設定,1,選択,相手モンスター.?性別:男,1",
             lines=[e1["josou"] or "侍女の衣装を持ってきて。この子に着せてあげましょう。"],
             body=["説明,男モンスターはストッキングと侍女のドレスを着せられた。"] + josou_cmds("効果対象")),
        dict(no=3, name="女王の招待状", type="通常魔法", rare="N",
             explain="自分のデッキからモンスター1枚をランダムに手札に加える。",
             flavor="黒い封筒に赤い封蝋。靴底の形の紋章が押された招待状は、断れた者のいない誘いだという。",
             target="効果ターゲット設定,1,ランダム,自分デッキ.?isモンスター:true,1",
             lines=["招待状を出しておいたわ。侍女を一人、呼びましょう。"], body=["効果サーチ,効果対象,自分所属"]),
        dict(no=4, name="絨毯の罠", type="通常罠", rare="R", trap=True,
             explain="相手の攻撃時に発動。攻撃してきたカードは攻撃不能1ターン。",
             flavor="赤い絨毯の毛足は深く柔らかい。一歩踏み込めば、女王の足元へ膝から沈んでいく。",
             lines=["足元をご覧なさい。そこはもう、私の絨毯の上よ。"],
             body=["状態異常付与,トリガー能動カード,攻撃不能,1"]),
        dict(no=5, name="玉座の間", type="永続魔法", rare="SR",
             explain="発動時と自分のターン終了時に服従度+1（男モンスターがいればそのうち1体、いなければ主人公）。3回目のターン終了時に自壊する。",
             flavor="赤い絨毯の先に据えられた黒い玉座。その前の低い足台は、侍女が夜ごと身を横たえる場所。",
             lines=["玉座の間へようこそ。足台の前で、よく見上げなさい。"], body=["$回数,=,0"] + add_rule(1, None, conv)),
    ]
    for m in MAG:
        img = f"{P}magic_{m['no']}.png"
        L = ["@初期設定", f"    &カード名,{m['name']}", f"    &カード画像,{img}", "    属性設定,闇属性",
             f"    タイプ設定,{m['type']}", f"    レアリティ設定,{m['rare']}"]
        if m.get("trap"):
            L += [f"    効果設定,1,forceTrigger,{m['explain']}", "    誘発効果設定,1,onAttack",
                  "    効果条件設定,1,トリガー能動カード.所属,!=,自分所属"]
        else:
            L += [f"    効果設定,1,play,{m['explain']}"]
        if m.get("target"):
            L += ["    " + m["target"]]
        if m["no"] == 5:
            L += ["    効果設定,2,forceTrigger,自分のターン終了時：服従度+1。3回目で自壊。",
                  "    誘発効果設定,2,エンドフェイズ開始時", "    効果条件設定,2,Now自分ターン,==,true"]
        L += [f"    効果設定,0,explain,{m['flavor']}", ""]
        body = m["body"]
        body = [b.replace(f"セリフ,{None}", f"セリフ,{m1['finish']}") for b in body]
        ef = ["@効果", "switch,効果ID", "case,1", "{", "    話者,自分プレイヤー", f"    画像,{img},1"]
        ef += [f"    セリフ,{s}" for s in m["lines"]] + ind(body, 4) + ["}"]
        if m["no"] == 5:
            b2 = ["話者,自分プレイヤー", "セリフ,玉座の間の灯りは、まだ落とさないわ。", "$回数,+=,1"] + \
                 [b.replace(f"セリフ,{None}", f"セリフ,{m1['finish']}") for b in add_rule(1, None, conv)]
            b2 += block("$回数,>=,3", ["セリフ,今夜の謁見はここまで。", "効果破壊,自分"])
            ef += ["case,2", "{"] + ind(b2, 4) + ["}"]
        ef += ["endswitch", ""]
        L += ef + ["@効果_街バトル", "    イベント実行,効果", ""]
        write(f"Card/{C}_magic_{m['no']}.txt", L)


def quest():
    d = os.path.join(OUT, "EventList", "Quest")
    os.makedirs(d, exist_ok=True)
    txt = (f"足の女王様のサロン,Card/{C}_master,クエストイベント\r\n"
           f"足の女王様のサロン【回想バトル】,Card/{C}_master,回想バトル,$$Heels_挑戦回数,>=,1")
    open(os.path.join(d, f"{C}.txt"), "w", encoding="utf-8", newline="").write(txt)
    d2 = os.path.join(OUT, "予備_回想メニュー用", "EventList", "Renoun")
    os.makedirs(d2, exist_ok=True)
    open(os.path.join(d2, f"{C}.txt"), "w", encoding="utf-8", newline="").write(
        f"足の女王様のサロン【回想バトル】,Card/{C}_master,回想バトル,$$Heels_挑戦回数,>=,1")


if __name__ == "__main__":
    master()
    for k in MONS:
        monster(k)
    josou_card()
    magic_all()
    quest()
    open(os.path.join(OUT, "必要な画像一覧.txt"), "w", encoding="utf-8").write("\n".join(sorted(IMAGES)) + "\n")
    print("generated", OUT, "images:", len(IMAGES))
