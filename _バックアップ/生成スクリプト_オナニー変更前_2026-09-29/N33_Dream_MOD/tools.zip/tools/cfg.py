# N33 夢魔の揺りかご（Dream）の設定（gen_v4.py 用）。登場人物は全員20歳以上。女性（夢魔）と男の娘（獏・悪夢）の混合。
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/home/claude/n3x/common")
from cfgkit import T, std_magic

S = "夢の階"
CFG = dict(
    code="Dream", outdir="N33_Dream_MOD", stack=S, sex="女", speaker_sex="女", attr="闇属性",
    bg="#Dream/Dream_bg.png", mon_fate="destroy",
    quest_name="夢魔の揺りかご（夢魔　ソムニア）", quest_name_kaisou="夢魔の揺りかご【回想バトル】",
    lose_title="―― 夢魔の揺りかご　永い眠り ――",
    player_full_desc="夢の階、十二段。……いちばん下の段に足が着いた。もう、目を覚ます方法は思い出せない。",
    conv_desc="男モンスターは夢の底へ沈み、二度と目を覚まさなかった。",
    magic_conv="夢の階、六段。……おやすみなさい。あなたのお連れは、もう朝を迎えないわ。",
    speakers=[("%ソムニア", "master", "女"), ("%ムウ", "e1", "女"), ("%メリー", "e2", "女"), ("%ナイト", "e3", "女"), ("%ネムリア", "boss", "女")],
    weak={"m1": "魔法責め", "m2": "キス", "m3": "本番", "e1": "キス", "e2": "ハグ", "e3": "触手", "boss": "魔法責め"},
    master=dict(
        name="夢魔　ソムニア", race="悪魔", sex="女", atk=500,
        explain=f"★得意技【囁きの子守唄】（子守唄だけで触れずに達させる）で受けた相手の【{S}】+3（主人公は12段で永い眠り＝敗北／男モンスターは6段で目覚めず破壊）。{S}は主人公とモンスターが別々に持つ。【夢の口づけ】は甘い口づけ。【夢と現の狭間で】（乳首舐め＋ふたなり逆アナル）は指で2回ほぐした後にだけ出せる。ターン終了時、主人公の{S}の段階に応じて 魅了／魅了／洗脳／洗脳＋500。",
        techs=[T("囁きの子守唄", "魔法責め", fav=3), T("夢の口づけ", "キス", eff="&&キスエフェクト"), T("夢と現の狭間で", "本番", insert=True)],
        turn_end_ops=[[("status_p", "魅了", 1)], [("status_p", "魅了", 1)], [("status_p", "洗脳", 1)],
                      [("status_p", "洗脳", 1), ("dmg_p", 500)]]),
    mons={
        "e1": dict(name="獏　ムウ", aid=4, lv=4, atk=500, hp=1400, rare="R", race="獣", sex="その他",
                   techs=[T("夢を食む舌", "キス", fav=2, eff="&&キスエフェクト"), T("枕元の囁き", "耳責め", st=("洗脳", 1))],
                   explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+1。★得意技【夢を食む舌】（夢ごとお尻を舐める）で受けた相手の{S}+2。【枕元の囁き】で洗脳1ターン。",
                   summon_ops=[("add", 1)]),
        "e2": dict(name="羊飼い　メリー", aid=5, lv=4, atk=450, hp=1500, rare="R", race="妖精", sex="女",
                   techs=[T("羊毛の愛撫", "ハグ", fav=2), T("数え歌", "耳責め")],
                   explain=f"★得意技【羊毛の愛撫】（羊毛で乳首を撫で続ける）で受けた相手の{S}+2。【数え歌】は数を数えさせて常識を書き換える。自分のターン終了時：男モンスター1体に魅了1ターン。",
                   end_ops=[("status_m_only", "魅了", 1)]),
        "e3": dict(name="悪夢　ナイト", aid=6, lv=4, atk=550, hp=1600, rare="R", race="悪魔", sex="その他",
                   techs=[T("影の触手", "触手", fav=2), T("悪夢の", "魔法責め")],
                   explain=f"召喚時：主人公に拘束1ターン（金縛り）。★得意技【影の触手】（影の触手でお尻を開く）で受けた相手の{S}+2。【悪夢の】は影の糸で尿道を内側から。",
                   summon_ops=[("status_p", "拘束", 1)]),
        "boss": dict(name="夢の女王　ネムリア", aid=7, lv=7, atk=1200, hp=6000, rare="SR", race="悪魔", sex="女",
                     techs=[T("夢でも現でも", "魔法責め", fav=3), T("女王の添い寝", "本番", insert=True, st=("寸止め", 1))],
                     explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+3。★得意技【夢でも現でも】（下腹の淫紋と影の触手でお尻を同時に）で受けた相手の{S}+3。【女王の添い寝】（ふたなり逆アナル。指で2回ほぐした後だけ）で寸止め1ターン。固有効果【永い眠り】自分のターン終了時、主人公の{S}が6以上なら、男モンスター1体に洗脳1ターンと{S}+1。",
                     summon_ops=[("add", 3)],
                     unique=dict(name="永い眠り", min=6, once=False, ops=[("m_status_add", "洗脳", 1, 1)])),
    },
    magic=std_magic(S, [("羊が一匹", "add", 2), ("夢の檻", "trap", "拘束"), ("子守唄", "target", ("洗脳", 1)),
                        ("夢渡り", "search", None), ("夜更かし禁止", "persist", None)]),
)
