#!/usr/bin/env python3
"""N30 忍びの隠れ里（Ninja）v4 カード一式の生成スクリプト。
入力: scen/<経路>_<key>.txt（#導入/#プレイ/#結び の3区画）, lines/<key>.json（v4）
出力: out/N30_Ninja_MOD/Card/*.txt, EventList/Quest/Ninja.txt （UTF-8・CRLF）
v4の決まり：得意技だけが術中度を積む／受けた側が個別に持つ（主人公12・男モンスター6）／
段階は受けた側のスタック／挿入技はほぐし2未満なら指ほぐし／クエスト＋回想バトル。
男モンスターが6に達した時の処理＝下忍として敵側へ（コントロール変更）。女装娘なし。
"""
import os, re, json

BASE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
SCEN = os.path.join(BASE, "scen")
LINES = os.path.join(BASE, "lines")
OUT = os.path.join(BASE, "out", "N30_Ninja_MOD")
C = "Ninja"
P = f"#{C}/{C}_"
ST = "$術中度"
HG = "$ほぐし"
PMAX, MMAX = 12, 6
G = f"$${C}_"  # グローバル変数の頭

ROUTES = [("btl", 1), ("onani", 2), ("inochi", 3), ("onedari", 4)]
ATTACKERS = [("m1", 1), ("m2", 2), ("m3", 3), ("e1", 4), ("e2", 5), ("e3", 6), ("boss", 7)]
AID = dict(ATTACKERS)
# 敗北後の弱点＝その責め手の得意技の攻撃タイプ
WEAK = {"m1": "魔法責め", "m2": "魔法責め", "m3": "魔法責め", "e1": "本番", "e2": "キス", "e3": "魔法責め", "boss": "乳首責め"}
SPEAKERS = [("%カゲロウ", "master"), ("%ハヤブサ", "e1"), ("%シグレ", "e2"), ("%ツムギ", "e3"), ("%オボロ", "boss")]
VANISH = "説明,男モンスターは紅い縄を掛けられ、里の下忍として相手側に加わった。"


def J(key):
    return json.load(open(os.path.join(LINES, f"{key}.json"), encoding="utf-8"))


def ind(lines, n=1):
    return [(" " * n) + l if l else l for l in lines]


def block(cond, body):
    return [f"if,{cond}", "{"] + ind(body) + ["}"]


def ifelse(cond, a, b):
    return [f"if,{cond}", "{"] + ind(a) + ["}else{"] + ind(b) + ["}"]


def staged(arr):
    out = []
    for i, s in enumerate(arr):
        out += block(f"$段階,==,{i+1}", [f"セリフ,{s}"])
    return out


# ------------------------------------------------------------ スタック
def target_calc():
    """$対象（0=主人公／1=男モンスター）、$値、$ほぐし値、$段階 を決める"""
    p = ["$対象,=,0", f"$値,=,相手プレイヤー.{ST}", f"$ほぐし値,=,相手プレイヤー.{HG}", "$段階,=,1"]
    p += block("$値,>=,4", ["$段階,=,2"]) + block("$値,>=,7", ["$段階,=,3"]) + block("$値,>=,10", ["$段階,=,4"])
    m = ["$対象,=,1", f"$値,=,相手.{ST}", f"$ほぐし値,=,相手.{HG}", "$段階,=,1"]
    m += block("$値,>=,2", ["$段階,=,2"]) + block("$値,>=,4", ["$段階,=,3"]) + block("$値,>=,5", ["$段階,=,4"])
    return ifelse("相手,==,相手プレイヤー", p, m)


def add_player(n, finish):
    b = [f"相手プレイヤー.{ST},+=,{n}", f"$表示用,=,相手プレイヤー.{ST}", f"説明,（あなたの術中度 {{$表示用}}／{PMAX}）"]
    b += block(f"相手プレイヤー.{ST},>=,{PMAX}", ["話者,自分", f"セリフ,{finish}", "とどめダメージ,相手プレイヤー,9999"])
    return b


def add_monster(n):
    b = [f"相手.{ST},+=,{n}", f"$表示用,=,相手.{ST}", f"説明,（男モンスターの術中度 {{$表示用}}／{MMAX}）"]
    b += block(f"相手.{ST},>=,{MMAX}", ["$変換,=,1"])
    return b


def add_rule(n, finish, conv):
    """魔法・罠・召喚時の +n：男モンスターがいればランダムに1体、いなければ主人公"""
    mon = ["カードランダム抜き出し,相手モンスター,1,%対象", f"%対象.{ST},+=,{n}", f"$表示用,=,%対象.{ST}",
           f"説明,（男モンスターの術中度 {{$表示用}}／{MMAX}）"]
    mon += block(f"%対象.{ST},>=,{MMAX}", [f"セリフ,{conv}", VANISH, "コントロール変更,%対象,自分所属"])
    pl = [f"相手プレイヤー.{ST},+=,{n}", f"$表示用,=,相手プレイヤー.{ST}", f"説明,（あなたの術中度 {{$表示用}}／{PMAX}）"]
    pl += block(f"相手プレイヤー.{ST},>=,{PMAX}", [f"セリフ,{finish}", "とどめダメージ,相手プレイヤー,9999"])
    return ifelse("相手モンスター.Count,>,0", mon, pl)


def status_rule(name, turns):
    """男モンスターがいればランダムに1体、いなければ主人公に状態異常"""
    return ifelse("相手モンスター.Count,>,0",
                  ["カードランダム抜き出し,相手モンスター,1,%対象", f"状態異常付与,%対象,{name},{turns}"],
                  [f"状態異常付与,相手プレイヤー,{name},{turns}"])


FINISH = None  # m1.json の finish


def tech_block(t, atype, cg, aid, gain=0, insert=False, extra=None, effect="&&セクシーエフェクト"):
    """1つの技。gain>0 なら得意技（受けた側に+gain）。
    insert＝挿入技（ほぐし2未満なら指ほぐし）。extra＝当たった時の追加処理"""
    def lines_for(tt):
        b = ["話者,自分", f"技名表示,{tt['name']}", f"画像,{cg},1"]
        b += ifelse("$対象,==,0", staged(tt["atk_p"]), staged(tt["atk_m"]))
        b += ["話者,相手"] + ifelse("$対象,==,0", staged(tt["rx_p"]), staged(tt["rx_m"]))
        return b + ["話者,自分", f"攻撃エフェクト変更,{effect}"]

    main = lines_for(t)
    main += block("$対象,==,0", [f"{G}最後の責め手,=,{aid}"])
    if gain:
        main += ifelse("$対象,==,0", add_player(gain, FINISH), add_monster(gain))
    if extra:
        main += extra
    if insert:
        h = t["hogushi"]
        hb = ["話者,自分", f"技名表示,{h['name']}", f"画像,{cg},1"]
        hb += ifelse("$対象,==,0",
                     ifelse("$ほぐし値,==,0", [f"セリフ,{h['atk_p'][0]}"], [f"セリフ,{h['atk_p'][1]}"]),
                     ifelse("$ほぐし値,==,0", [f"セリフ,{h['atk_m'][0]}"], [f"セリフ,{h['atk_m'][1]}"]))
        hb += ["話者,相手"] + ifelse("$対象,==,0",
                                    ifelse("$ほぐし値,==,0", [f"セリフ,{h['rx_p'][0]}"], [f"セリフ,{h['rx_p'][1]}"]),
                                    ifelse("$ほぐし値,==,0", [f"セリフ,{h['rx_m'][0]}"], [f"セリフ,{h['rx_m'][1]}"]))
        hb += ["話者,自分"]
        hb += ifelse("$対象,==,0",
                     [f"{G}最後の責め手,=,{aid}", f"相手プレイヤー.{HG},+=,1", f"$表示用,=,相手プレイヤー.{HG}",
                      "説明,（ほぐし {$表示用}／2）"],
                     [f"相手.{HG},+=,1", f"$表示用,=,相手.{HG}", "説明,（男モンスターのほぐし {$表示用}／2）"])
        if gain:  # 得意技が挿入技のキャラは指ほぐしでも+1
            hb += ifelse("$対象,==,0", add_player(1, FINISH), add_monster(1))
        body = ifelse("$ほぐし値,<,2", hb, main)
    else:
        body = main
    return block(f"攻撃タイプ,==,{atype}", body)


def battle_section(types, techs):
    out = ["@戦闘", "攻撃タイプランダム変更," + ",".join(types), "$変換,=,0"] + target_calc()
    for t in techs:
        out += t
    return out + [""]


def after_battle(conv, conv_rx):
    b = ["@戦闘後"]
    b += block("$変換,==,1", ["話者,自分", f"セリフ,{conv}", "話者,相手", f"セリフ,{conv_rx}", VANISH, "コントロール変更,相手,自分所属"])
    b += ["$変換,=,0", ""]
    return b


def street_hooks(sections):
    out = []
    for s in sections:
        out += [f"@{s}_街バトル", f"    イベント実行,{s}", ""]
    return out


# ------------------------------------------------------------ シナリオ
def read_scen(route, key):
    lines = [l.rstrip("\r\n") for l in open(os.path.join(SCEN, f"{route}_{key}.txt"), encoding="utf-8-sig")]
    return [l for l in lines if l.strip() and not l.startswith("#")]


def scen_section(route, key):
    body = read_scen(route, key)
    return [f"@敗北_{route}_{key}"] + ind(body, 4) + [
        "    フラッシュ,白",
        "    説明,―― 霞隠れの里　里の者　成立 ――",
        f"    主人公攻撃タイプ弱点付与,{WEAK[key]},50",
        ""]


def dispatch():
    out = [f"話者生成,{v},{P}{img}.png,その他" for v, img in SPEAKERS]
    for key, aid in ATTACKERS:
        inner = []
        for r, rid in ROUTES:
            inner += block(f"$経路,==,{rid}", [f"イベント実行,敗北_{r}_{key}"])
        out += block(f"$責め手,==,{aid}", inner)
    return out


# ------------------------------------------------------------ 後処理
_IMG = re.compile(r"^(\s*)画像,(#[^,]+),(.*)$")
_SPK = re.compile(r"^(\s*)話者生成,(%[^,]+),(#[^,]+),(.*)$")


def var_images(lines):
    """# 画像を @初期設定 の & 変数に置き換える（実機で直接パスは出なかった）"""
    defs, out = {}, []

    def var(path):
        name = "&画像_" + os.path.splitext(os.path.basename(path))[0]
        defs[name] = path
        return name
    for l in lines:
        m = _IMG.match(l)
        if m:
            sp, path, rest = m.groups()
            out.append(f"{sp}画像,{var(path)},{rest}")
            continue
        m = _SPK.match(l)
        if m:
            sp, v, path, rest = m.groups()
            out.append(f"{sp}話者生成,{v},{var(path)},{rest}")
            continue
        out.append(l)
    if defs:
        i = out.index("@初期設定") + 1
        out[i:i] = [f"    {k},{p}" for k, p in sorted(defs.items())]
    return out


IMAGES = set()


def write(rel, lines):
    lines = var_images(lines)
    for l in lines:
        m = re.search(rf"#{C}/([^,]+\.png)", l)
        if m:
            IMAGES.add(m.group(1))
    path = os.path.join(OUT, rel)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="") as f:
        f.write("\r\n".join(["default"] + lines) + "\r\n")


def common_init(name, img, lv, atk, hp, typ, rare, explain, flavor, sex="その他"):
    return ["@初期設定", f"    &カード名,{name}", f"    &カード画像,{img}",
            f"    レベル設定,{lv}", f"    攻撃力設定,{atk}", f"    最大HP設定,{hp}",
            "    属性設定,闇属性", f"    タイプ設定,{typ}", f"    性別設定,{sex}", f"    レアリティ設定,{rare}",
            "    攻撃エフェクト設定,&&セクシーエフェクト",
            f"    効果設定,1,explain,{explain}" if explain else None,
            f"    効果設定,0,explain,{flavor}"]


# ------------------------------------------------------------ マスター
DECK = [f"{C}_mons_e1"] * 3 + [f"{C}_mons_e2"] * 3 + [f"{C}_mons_e3"] * 3 + [f"{C}_mons_boss"] + \
       [f"{C}_magic_{i}" for i in range(1, 6) for _ in range(2)]


def lose_play(record):
    b = ["BGM,&&敗北BGM", f"$経路,=,{G}敗北経路"] + block("$経路,==,0", ["$経路,=,1"]) + \
        block("死亡理由,==,オナニー", ["$経路,=,1"]) + [f"$責め手,=,{G}最後の責め手"] + \
        block("$責め手,==,0", ["$責め手,=,1"]) + ["イベント実行,敗北再生"]
    if record:
        b += [f"{G}敗北回数,+=,1", f"{G}前回敗北経路,=,$経路", f"{G}前回最後の責め手,=,$責め手"]
    return b + ["説明,GAME OVER"]


def reset_globals():
    return [f"{G}最後の責め手,=,1", f"{G}敗北経路,=,0"]


def master():
    global FINISH
    m1, m2, m3 = J("m1"), J("m2"), J("m3")
    FINISH = m1["finish"]
    L = [x for x in common_init(
        "頭領 カゲロウ", f"{P}master.png", 8, 1000, 10000, "戦士", "UR",
        f"★得意技【房中術】で攻撃を受けた者の【術中度】+3（主人公と男モンスターが別々に持つ。減らない）。主人公は{PMAX}で里の者（敗北）。男モンスターは{MMAX}で下忍として相手側へ寝返る。【縄術と舌】を受けた者は拘束1ターン。【分身の術】は相手のほぐしが2未満なら指ほぐし。ターン終了時：主人公の術中度に応じて拘束（1〜6）・攻撃指示不能（7〜11）。",
        m1["flavor"]) if x]
    L += [f"    &技CG_1,{P}atk_m1.png", f"    &技CG_2,{P}atk_m2.png", f"    &技CG_3,{P}atk_m3.png",
          f"    &背景,{P}bg.png", ""]

    # --- クエストイベント
    f = m1["first"]
    first = ["背景,&背景", f"説明,{f[0]}", f"説明,{f[1]}", "画像,&カード画像,1",
             f"セリフ,{f[2]}", f"セリフ,{f[3]}", f"セリフ,{f[4]}"]
    won = ["画像,&カード画像,1"] + [f"セリフ,{s}" for s in m1["won"]]
    prev = ["画像,&カード画像,1"]
    for i, s in enumerate(m1["prev"]):
        prev += block(f"{G}前回敗北経路,==,{i+1}", [f"セリフ,{s}"])
    prev += ["アラート,前回の続きから始めますか？", "選択肢生成,勝負する,誘いに乗る（前回の続き）,引き返す"]
    prev += block("選択肢,==,2", [f"セリフ,{m1['continue']}", "イベント実行,前回続き", "イベント終了"])
    prev += block("選択肢,==,3", [f"セリフ,{m1['decline']}", "イベント終了"])
    qe = ["@クエストイベント", "話者,自分"]
    qe += ifelse(f"{G}敗北回数,==,0", ifelse(f"{G}挑戦回数,==,0", first, won),
                 ifelse("is前回プレイヤー勝利,==,true", won, prev))
    qe += [f"{G}回想バトル,=,0", f"{G}挑戦回数,+=,1"] + reset_globals()
    qe += ["デッキ設定," + ",".join(DECK), "デッキ報酬設定,300,300,0", "バトル開始,&背景,&&戦闘BGM"]
    qe += ifelse("is敗北,==,true", lose_play(True),
                 ["BGM,&&戦闘BGM", "背景,&背景", "画像,&カード画像,1", "話者,自分", f"セリフ,{m1['win']}"]) + [""]
    L += qe

    # --- 回想バトル
    k = m1["kaisou"]
    kb = ["@回想バトル", "話者,自分", "背景,&背景", "画像,&カード画像,1", f"セリフ,{k['open']}",
          f"{G}回想バトル,=,1"] + reset_globals()
    kb += ["デッキ設定," + ",".join(DECK), "バトル開始,&背景,&&戦闘BGM"]
    kb += ifelse("is敗北,==,true", lose_play(False),
                 ["BGM,&&戦闘BGM", "背景,&背景", "画像,&カード画像,1", "話者,自分", f"セリフ,{m1['win']}"])
    kb += ["話者,自分", f"セリフ,{k['end']}", f"{G}回想バトル,=,0", ""]
    L += kb

    menu = ["@回想メニュー", "話者,自分", f"セリフ,{k['menu']}", "$続ける,=,1", "while,$続ける,==,1", "{"]
    inner = ["選択肢生成,デッキから選んで場に呼ばせる,デッキから選んで手札に加えさせる,カードを1枚引かせる,このまま進める"]
    inner += block("選択肢,==,1", ["%候補,=,自分デッキ.?isモンスター:true"] + ifelse(
        "%候補.Count,>,0", ["カード選択,%候補,1,1", f"セリフ,{k['summon']}", "特殊召喚,選択カード,味方"],
        ["説明,デッキにモンスターが残っていない。"]))
    inner += block("選択肢,==,2", ["%候補,=,自分デッキ"] + ifelse(
        "%候補.Count,>,0", ["カード選択,%候補,1,1", f"セリフ,{k['search']}", "効果サーチ,選択カード,自分所属"],
        ["説明,デッキにカードが残っていない。"]))
    inner += block("選択肢,==,3", [f"セリフ,{k['draw']}", "効果ドロー,自分プレイヤー"])
    inner += block("選択肢,==,4", [f"セリフ,{k['go']}", "$続ける,=,0"])
    menu += ind(inner) + ["}", ""]
    L += menu

    L += ["@試合開始", f"相手プレイヤー.{ST},=,0", f"相手プレイヤー.{HG},=,0", "自分プレイヤー.$影縫い,=,0", "話者,自分"] + \
         [f"セリフ,{s}" for s in m1["start"]] + block(f"{G}回想バトル,==,1", ["イベント実行,回想メニュー"]) + [""]
    L += ["@ターン開始"] + block(f"{G}回想バトル,==,1", ["イベント実行,回想メニュー"]) + [""]

    stage_p = [f"$値,=,相手プレイヤー.{ST}", "$段階,=,1"] + block("$値,>=,4", ["$段階,=,2"]) + \
              block("$値,>=,7", ["$段階,=,3"]) + block("$値,>=,10", ["$段階,=,4"])
    L += ["@召喚宣言"] + stage_p + ["話者,自分"] + staged(m1["summon"]) + [""]

    t1 = tech_block(m1["tech"], "乳首責め", "&技CG_1", 1, extra=["状態異常付与,相手,拘束,1"])
    t2 = tech_block(m2["tech"], "魔法責め", "&技CG_2", 2, gain=3)
    t3 = tech_block(m3["tech"], "本番", "&技CG_3", 3, insert=True)
    L += battle_section(["乳首責め", "魔法責め", "本番"], [t1, t2, t3])
    L += after_battle(m1["conv"], m1["conv_rx"])

    te = ["@ターン終了宣言"] + stage_p + ["話者,自分"]
    eff = [("拘束", 1), ("拘束", 1), ("攻撃指示不能", 1), ("攻撃指示不能", 1)]
    for i, s in enumerate(m1["turnend"]):
        te += block(f"$段階,==,{i+1}", [f"セリフ,{s}", f"状態異常付与,相手プレイヤー,{eff[i][0]},{eff[i][1]}"])
    te = te[:len(stage_p) + 2] + block("$値,>=,1", te[len(stage_p) + 2:])  # 術中度0の間は何もしない
    te += block(f"相手プレイヤー.{ST},>=,{PMAX}", [f"セリフ,{FINISH}", "とどめダメージ,相手プレイヤー,9999"])
    L += te + [""]

    # おねだり
    L += ["@おねだり", "話者,自分", "画像,&カード画像,1", f"セリフ,{m1['onedari_open']}",
          f"選択肢生成,{m1['tech']['name']},{m2['tech']['name']},{m3['tech']['name'].replace('【同時】', '')}"]
    for i, (mm, at) in enumerate([(m1, "乳首責め"), (m2, "魔法責め"), (m3, "本番")]):
        L += block(f"選択肢,==,{i+1}", ["話者,相手", f"セリフ,{mm['onedari']}", "話者,自分",
                                        "セリフ,……よい。その口で言うたこと、わたしは忘れぬぞ。", f"攻撃タイプ固定,{at}",
                                        f"{G}最後の責め手,=,{i+1}"])
    L += [f"{G}敗北経路,=,4", "状態異常付与,自分,弱点付与スキル,1", ""]
    L += ["@おねだり後", "攻撃タイプ固定解除", "状態異常解除,自分,弱点付与スキル"] + \
         block("相手プレイヤー.HP,>,0", [f"{G}敗北経路,=,0"]) + [""]

    # 命乞い
    ino = ["@命乞い", "話者,自分", "画像,&カード画像,1"]
    ino += ifelse("命乞い回数,>=,2", [f"セリフ,{s}" for s in m1["inochi2"]], [f"セリフ,{s}" for s in m1["inochi"]])
    ino += ["選択肢生成,とどめを刺す,手を止める"]
    ino += block("選択肢,==,1", [f"セリフ,{m1['inochi_fail']}", "命乞い失敗", "イベント終了"])
    ino += block(f"{G}最後の責め手,>,3", [f"{G}最後の責め手,=,1"])
    ino += [f"{G}敗北経路,=,3", "説明,紅い縄の結び目が目に入った一瞬、とどめのカードを出す手が止まった。",
            f"セリフ,{m1['inochi_trap']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ino

    # オナニー（得意技＝九本の尾に合わせた自慰）
    o = m1["onani"]
    ona = ["@オナニー", f"{G}敗北経路,=,1"]
    ona += block(f"{G}最後の責め手,>,3", [f"{G}最後の責め手,=,1"])
    ona += [f"説明,{o['desc'][0]}", f"説明,{o['desc'][1]}", "話者,自分"]
    ona += ifelse("オナニー回数,>=,2", [f"セリフ,{s}" for s in o["atk2"]], [f"セリフ,{s}" for s in o["atk"]])
    ona += ["話者,相手", f"セリフ,{o['rx']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ona

    L += ["@終了時一言", "話者,自分", f"セリフ,{m1['end']}", ""]
    L += ["@敗北再生", "背景,&背景", "画像,&カード画像,1", "フェードイン,1"] + dispatch() + [""]
    L += ["@前回続き", f"$経路,=,{G}前回敗北経路", f"$責め手,=,{G}前回最後の責め手"] + \
         block("$経路,==,0", ["$経路,=,1"]) + block("$責め手,==,0", ["$責め手,=,1"]) + \
         ["BGM,&&敗北BGM", "イベント実行,敗北再生", f"{G}敗北回数,+=,1", "説明,GAME OVER", ""]
    for r, _ in ROUTES:
        for a, _ in ATTACKERS:
            L += scen_section(r, a)
    L += street_hooks(["戦闘", "戦闘後", "オナニー", "おねだり", "おねだり後", "命乞い", "終了時一言"])
    write(f"Card/{C}_master.txt", L)


# ------------------------------------------------------------ モンスター
MONS = {
    "e1": dict(name="下忍 ハヤブサ", lv=4, atk=1200, hp=1500, rare="R", types=["ハグ", "本番"], gain=2,
               explain="★得意技【張形の術】：受けた者の術中度+2・ほぐし+1。【縄目で】を受けた者は拘束1ターン。召喚時：術中度+1（男モンスターがいればそのうち1体、いなければ主人公）。"),
    "e2": dict(name="幻術使い シグレ", lv=4, atk=1100, hp=1600, rare="R", types=["耳責め", "キス"], gain=2,
               explain="★得意技【影の舌】：受けた者の術中度+2。【幻術】を受けた者は洗脳1ターン。自分のターン終了時：男モンスター1体に魅了1ターン（いなければ主人公）。"),
    "e3": dict(name="薬師 ツムギ", lv=4, atk=1300, hp=1400, rare="R", types=["魔法責め", "キス"], gain=2,
               explain="★得意技【秘薬のゼリー】：受けた者の術中度+2。【秘薬の口移し】を受けた者は発情1ターン。召喚時：男モンスター1体に寸止め2ターン（いなければ主人公）。"),
    "boss": dict(name="上忍 オボロ", lv=7, atk=2400, hp=3200, rare="SR", types=["乳首責め", "本番"], gain=3,
                 explain="★得意技【分身の術】：受けた者の術中度+3。【奥義】は受けた側のほぐしが2未満なら指ほぐし。召喚時：術中度+3。固有効果【影縫い】：主人公の術中度6以上なら、自分のターン終了時に1試合1回、男モンスター全体に攻撃指示不能1ターン・主人公に拘束1ターン。"),
}


def monster(key):
    m, d = MONS[key], J(key)
    aid = AID[key]
    img = f"{P}{key}.png"
    L = [x for x in common_init(m["name"], img, m["lv"], m["atk"], m["hp"], "戦士", m["rare"], None, d["flavor"]) if x]
    L += [f"    &技CG,{P}atk_{key}.png",
          f"    効果設定,1,forceTrigger,{m['explain']}", "    誘発効果設定,1,場に出た時",
          "    効果条件設定,1,トリガー受動カード,==,自分"]
    if key in ("e2", "boss"):
        L += ["    効果設定,2,forceTrigger,自分のターン終了時に発動する効果。", "    誘発効果設定,2,エンドフェイズ開始時",
              "    効果条件設定,2,Now自分ターン,==,true"]
    L += [""]

    ef = ["@効果", "switch,効果ID", "case,1", "{", "    話者,自分", f"    画像,{img},1"]
    ef += [f"    セリフ,{s}" for s in d["summon"]]
    if d.get("summon_effect"):
        ef += [f"    セリフ,{d['summon_effect']}"]
    if key == "e1":
        ef += ind(add_rule(1, FINISH, d["conv"]), 4)
    if key == "boss":
        ef += ind(add_rule(3, FINISH, d["conv"]), 4)
    if key == "e3":
        ef += ind(status_rule("寸止め", 2), 4)
    ef += ["}"]
    if key == "e2":
        ef += ["case,2", "{", "    話者,自分", f"    セリフ,{d['turnend']}"] + ind(status_rule("魅了", 1), 4) + ["}"]
    if key == "boss":
        body = ["話者,自分", f"セリフ,{d['turnend']}", "説明,【影縫い】影に影針が打ち込まれ、男モンスターたちは動けなくなった。",
                "自分プレイヤー.$影縫い,=,1", "状態異常付与,相手プレイヤー,拘束,1"]
        body += block("相手モンスター.Count,>,0", ["状態異常付与,相手モンスター,攻撃指示不能,1"])
        ef += ["case,2", "{"] + ind(block(f"相手プレイヤー.{ST},>=,6", block("自分プレイヤー.$影縫い,==,0", body)), 4) + ["}"]
    ef += ["endswitch", ""]
    L += ef

    t1, t2 = d["techs"]
    techs = []
    if key == "e1":
        hog = ifelse("$対象,==,0", [f"相手プレイヤー.{HG},+=,1"], [f"相手.{HG},+=,1"])
        techs.append(tech_block(t1, "ハグ", "&技CG", aid, extra=["状態異常付与,相手,拘束,1"]))
        techs.append(tech_block(t2, "本番", "&技CG", aid, gain=2, extra=hog))
    elif key == "e2":
        techs.append(tech_block(t1, "耳責め", "&技CG", aid, extra=["状態異常付与,相手,洗脳,1"]))
        techs.append(tech_block(t2, "キス", "&技CG", aid, gain=2, effect="&&キスエフェクト"))
    elif key == "e3":
        techs.append(tech_block(t1, "魔法責め", "&技CG", aid, gain=2))
        techs.append(tech_block(t2, "キス", "&技CG", aid, extra=["状態異常付与,相手,発情,1"], effect="&&キスエフェクト"))
    else:
        techs.append(tech_block(t1, "乳首責め", "&技CG", aid, gain=3))
        techs.append(tech_block(t2, "本番", "&技CG", aid, insert=True))
    L += battle_section(m["types"], techs)
    L += after_battle(d["conv"], d["conv_rx"])

    L += ["@おねだり", "話者,自分", "画像,&カード画像,1", f"セリフ,{d['onedari_open']}",
          f"選択肢生成,{t1['name'].replace('【同時】', '')},{t2['name'].replace('【同時】', '')}"]
    for i in range(2):
        L += block(f"選択肢,==,{i+1}", ["話者,相手", f"セリフ,{d['onedari'][i]}", "話者,自分", "セリフ,……聞き届けた。",
                                        f"攻撃タイプ固定,{m['types'][i]}"])
    L += [f"{G}最後の責め手,=,{aid}", f"{G}敗北経路,=,4", "状態異常付与,自分,弱点付与スキル,1", ""]
    L += ["@おねだり後", "攻撃タイプ固定解除", "状態異常解除,自分,弱点付与スキル"] + \
         block("相手プレイヤー.HP,>,0", [f"{G}敗北経路,=,0"]) + [""]

    ino = ["@命乞い", "話者,自分", "画像,&カード画像,1"] + [f"セリフ,{s}" for s in d["inochi"]]
    ino += ["選択肢生成,とどめを刺す,手を止める"]
    ino += block("選択肢,==,1", ["セリフ,……そうか。", "命乞い失敗", "イベント終了"])
    ino += [f"{G}最後の責め手,=,{aid}", f"{G}敗北経路,=,3",
            "説明,とどめの一撃を出すはずの手が、ほんの一瞬止まった。",
            f"セリフ,{d['inochi_trap']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ino

    o = d["onani"]
    ona = ["@オナニー", f"{G}最後の責め手,=,{aid}", f"{G}敗北経路,=,1",
           f"説明,{o['desc'][0]}", f"説明,{o['desc'][1]}", "話者,自分"] + [f"セリフ,{s}" for s in o["atk"]]
    ona += ["話者,相手", f"セリフ,{o['rx']}", "とどめダメージ,相手プレイヤー,9999", ""]
    L += ona
    L += ["@終了時一言", "話者,自分", f"セリフ,{d['end']}", ""]
    L += ["@敗北後"] + block("is敗北,==,false", ["話者,自分", f"セリフ,{d['win']}"]) + [""]
    L += street_hooks(["戦闘", "戦闘後", "オナニー", "おねだり", "おねだり後", "命乞い", "終了時一言", "効果"])
    write(f"Card/{C}_mons_{key}.txt", L)


# ------------------------------------------------------------ 魔法・罠
def magic_all():
    m1 = J("m1")
    conv = m1["conv"]
    MAG = [
        dict(no=1, name="煙玉", type="通常魔法", rare="R",
             explain="術中度+2（男モンスターがいればそのうち1体、いなければ主人公）。",
             flavor="足元で弾ける白い煙。晴れた時にはもう、背後に誰かが立っている。気配だけが肌に残る。",
             lines=["煙玉。……息を吸うがよい。煙が晴れる頃には、もう術の中ぞ。"], body=add_rule(2, None, conv)),
        dict(no=2, name="幻の術", type="通常魔法", rare="SR",
             explain="相手の男モンスター1体を選び、洗脳1ターン。",
             flavor="香炉のひと筋の煙。それを吸った者の目には、主の姿が里の頭領に見えてくる。",
             target="効果ターゲット設定,1,選択,相手モンスター.?性別:男,1",
             lines=["この煙を吸うがよい。……ほら、もう主の声が遠くなったであろう。"],
             body=["説明,男モンスターは幻の術に囚われ、主の声が届かなくなった。", "状態異常付与,効果対象,洗脳,1"]),
        dict(no=3, name="伝令の鷹", type="通常魔法", rare="N",
             explain="自分のデッキからモンスター1枚をランダムに手札に加える。",
             flavor="谷の上を一羽の鷹が舞う。足に結んだ文を読んだ忍びが、音もなく屋敷の梁に降り立つ。",
             target="効果ターゲット設定,1,ランダム,自分デッキ.?isモンスター:true,1",
             lines=["鷹を飛ばした。……里の者が、すぐに参る。"], body=["効果サーチ,効果対象,自分所属"]),
        dict(no=4, name="縄の罠", type="通常罠", rare="R", trap=True,
             explain="相手の攻撃時に発動。攻撃してきたカードは拘束1ターン。",
             flavor="踏み込んだ足元で、紅い縄が跳ね上がる。気づいた時には、もう結び目の内側にいる。",
             lines=["踏んだな。……そこは、はじめから縄の内ぞ。"],
             body=["状態異常付与,トリガー能動カード,拘束,1"]),
        dict(no=5, name="隠れ里", type="永続魔法", rare="SR",
             explain="発動時と自分のターン終了時に術中度+1（男モンスターがいればそのうち1体、いなければ主人公）。3回目のターン終了時に自壊する。",
             flavor="霧の向こうに茅葺きの屋根が並ぶ。道を行けば行くほど、里の奥へ戻ってくる。",
             lines=["霧を張れ。……侵入者殿、ここはもう霞隠れの里。出口は、わたしが決める。"], body=["$回数,=,0"] + add_rule(1, None, conv)),
    ]
    for m in MAG:
        img = f"{P}magic_{m['no']}.png"
        L = ["@初期設定", f"    &カード名,{m['name']}", f"    &カード画像,{img}", "    属性設定,闇属性",
             f"    タイプ設定,{m['type']}", f"    レアリティ設定,{m['rare']}"]
        if m.get("trap"):
            L += [f"    効果設定,1,forceTrigger,{m['explain']}", "    誘発効果設定,1,onAttack",
                  "    効果条件設定,1,トリガー能動カード.所属,!=,自分所属"]
        else:
            L += [f"    効果設定,1,play,{m['explain']}"]
        if m.get("target"):
            L += ["    " + m["target"]]
        if m["no"] == 5:
            L += ["    効果設定,2,forceTrigger,自分のターン終了時：術中度+1。3回目で自壊。",
                  "    誘発効果設定,2,エンドフェイズ開始時", "    効果条件設定,2,Now自分ターン,==,true"]
        L += [f"    効果設定,0,explain,{m['flavor']}", ""]
        body = [b.replace(f"セリフ,{None}", f"セリフ,{m1['finish']}") for b in m["body"]]
        ef = ["@効果", "switch,効果ID", "case,1", "{", "    話者,自分プレイヤー", f"    画像,{img},1"]
        ef += [f"    セリフ,{s}" for s in m["lines"]] + ind(body, 4) + ["}"]
        if m["no"] == 5:
            b2 = ["話者,自分プレイヤー", "セリフ,霧はまだ晴れぬ。……もう一歩、里の奥へ。", "$回数,+=,1"] + \
                 [b.replace(f"セリフ,{None}", f"セリフ,{m1['finish']}") for b in add_rule(1, None, conv)]
            b2 += block("$回数,>=,3", ["セリフ,霧を解く。……もっとも、もう里から出る道は覚えておらぬであろう。", "効果破壊,自分"])
            ef += ["case,2", "{"] + ind(b2, 4) + ["}"]
        ef += ["endswitch", ""]
        L += ef + ["@効果_街バトル", "    イベント実行,効果", ""]
        write(f"Card/{C}_magic_{m['no']}.txt", L)


def quest():
    d = os.path.join(OUT, "EventList", "Quest")
    os.makedirs(d, exist_ok=True)
    txt = (f"忍びの隠れ里,Card/{C}_master,クエストイベント\r\n"
           f"忍びの隠れ里【回想バトル】,Card/{C}_master,回想バトル,{G}挑戦回数,>=,1")
    open(os.path.join(d, f"{C}.txt"), "w", encoding="utf-8", newline="").write(txt)
    d2 = os.path.join(OUT, "予備_回想メニュー用", "EventList", "Renoun")
    os.makedirs(d2, exist_ok=True)
    open(os.path.join(d2, f"{C}.txt"), "w", encoding="utf-8", newline="").write(
        f"忍びの隠れ里【回想バトル】,Card/{C}_master,回想バトル,{G}挑戦回数,>=,1")


if __name__ == "__main__":
    master()
    for k in MONS:
        monster(k)
    magic_all()
    quest()
    open(os.path.join(OUT, "必要な画像一覧.txt"), "w", encoding="utf-8").write("\n".join(sorted(IMAGES)) + "\n")
    print("generated", OUT, "images:", len(IMAGES))
