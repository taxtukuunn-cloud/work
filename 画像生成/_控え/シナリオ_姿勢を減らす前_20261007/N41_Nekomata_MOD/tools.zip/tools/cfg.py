# N41 猫又の屋敷（Nekomata）の設定（gen_v4.py 用）。登場人物は全員20歳以上。女性と男の娘の猫又の混合。
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/home/claude/n3x/common")
from cfgkit import T, std_magic

S = "肉球印"
CFG = dict(
    code="Nekomata", outdir="N41_Nekomata_MOD", stack=S, sex="女", speaker_sex="女", attr="闇属性",
    bg="#Nekomata/Nekomata_bg.png",
    quest_name="猫又の屋敷（猫又　タマキ）", quest_name_kaisou="猫又の屋敷【回想バトル】",
    lose_title="―― 猫又の屋敷　鈴の首輪 ――",
    player_full_desc="肉球印、十二。……首に赤い首輪と小さな鈴が留められた。僕は、この屋敷の飼い人になった。",
    conv_desc="男モンスターの首に鈴の首輪が留められ、飼い人として屋敷の側へ移った。",
    magic_conv="肉球印、六つ。……お連れさんも、今日からうちの子やね。首輪、似合うてるよぉ。",
    speakers=[("%タマキ", "master", "女"), ("%スミ", "e1", "女"), ("%ミケ", "e2", "女"), ("%チャイ", "e3", "女"), ("%オウカ", "boss", "女")],
    weak={"m1": "乳首責め", "m2": "触手", "m3": "本番", "e1": "ハグ", "e2": "キス", "e3": "触手", "boss": "乳首責め"},
    master=dict(
        name="猫又　タマキ", race="獣", sex="女", atk=500,
        explain=f"★得意技【ざらつく舌】（ざらついた猫の舌で乳首を舐め上げる）で受けた相手の【{S}】+3（主人公は12で飼い人＝敗北／男モンスターは6で飼い人として敵側へ）。{S}は主人公とモンスターが別々に持つ。【二股の尻尾】は尻尾でお尻を開く。【喉を鳴らしながら】（口づけ＋ふたなり逆アナル）は指で2回ほぐした後にだけ出せる。ターン終了時、主人公の{S}の段階に応じて 魅了／魅了／発情／発情＋500。",
        techs=[T("ざらつく舌", "乳首責め", fav=3), T("二股の尻尾", "触手"), T("喉を鳴らしながら", "本番", insert=True)],
        turn_end_ops=[[("status_p", "魅了", 1)], [("status_p", "魅了", 1)], [("status_p", "発情", 1)],
                      [("status_p", "発情", 1), ("dmg_p", 500)]]),
    mons={
        "e1": dict(name="黒猫　スミ", aid=4, lv=4, atk=450, hp=1400, rare="R", race="獣", sex="その他",
                   techs=[T("肉球の", "ハグ", fav=2), T("夜の囁き", "耳責め", st=("洗脳", 1))],
                   explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+1。★得意技【肉球の】（肉球で乳首を押しては離す）で受けた相手の{S}+2。【夜の囁き】で洗脳1ターン。",
                   summon_ops=[("add", 1)]),
        "e2": dict(name="三毛猫　ミケ", aid=5, lv=4, atk=500, hp=1500, rare="R", race="獣", sex="女",
                   techs=[T("毛づくろい", "キス", fav=2, eff="&&キスエフェクト"), T("マタタビの", "魔法責め")],
                   explain=f"★得意技【毛づくろい】（ざらつく舌でお尻を丁寧に舐める）で受けた相手の{S}+2。【マタタビの】は匂いで頭をとろかす。自分のターン終了時：男モンスター1体に発情1ターン。",
                   end_ops=[("status_m_only", "発情", 1)]),
        "e3": dict(name="茶トラ　チャイ", aid=6, lv=4, atk=550, hp=1600, rare="R", race="獣", sex="その他",
                   techs=[T("尻尾の先で", "触手", fav=2), T("踏み踏み", "足コキ")],
                   explain=f"召喚時：男モンスター1体に魅了1ターン。★得意技【尻尾の先で】（細い尻尾の先で尿道の内側を）で受けた相手の{S}+2。【踏み踏み】は足で踏み踏みする。",
                   summon_ops=[("status_m_only", "魅了", 1)]),
        "boss": dict(name="猫又の長　オウカ", aid=7, lv=7, atk=1200, hp=6000, rare="SR", race="獣", sex="女",
                     techs=[T("膝枕の毛づくろい", "乳首責め", fav=3), T("長の交わり", "本番", insert=True, st=("寸止め", 1))],
                     explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+3。★得意技【膝枕の毛づくろい】（膝枕で乳首を舐めながら指でお尻をほぐす）で受けた相手の{S}+3。【長の交わり】（ふたなり逆アナル。指で2回ほぐした後だけ）で寸止め1ターン。固有効果【鈴の首輪】自分のターン終了時、主人公の{S}が6以上なら、男モンスター1体にメロメロ2ターン。",
                     summon_ops=[("add", 3)],
                     unique=dict(name="鈴の首輪", min=6, once=False, ops=[("status_m_only", "メロメロ", 2)])),
    },
    magic=std_magic(S, [("マタタビ", "add", 2), ("猫じゃらし", "target", ("魅了", 1)), ("猫の集会", "search", None),
                        ("縁側の罠", "trap", "拘束"), ("猫の屋敷", "persist", None)]),
)
