# N35 堕天使の礼拝堂（Angel）の設定（gen_v4.py 用）。登場人物は全員20歳以上。女性（堕天使）と男の娘（天使）の混合。
import os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, "/home/claude/n3x/common")
from cfgkit import T, std_magic

S = "堕羽"
CFG = dict(
    code="Angel", outdir="N35_Angel_MOD", stack=S, sex="女", speaker_sex="女", attr="光属性",
    bg="#Angel/Angel_bg.png",
    quest_name="堕天使の礼拝堂（堕天使　ルシエル）", quest_name_kaisou="堕天使の礼拝堂【回想バトル】",
    lose_title="―― 堕天使の礼拝堂　黒い福音 ――",
    player_full_desc="堕羽、十二枚。……胸に落ちた最後の黒い羽根が、もう払っても消えない。僕は、堕天使の信徒になった。",
    conv_desc="男モンスターの肩に黒い羽根が降り積もり、聖歌隊として礼拝堂の側へ移った。",
    magic_conv="堕羽、六枚。……迷える子羊がまた一匹、赦されました。今日から聖歌隊で歌いなさい。",
    speakers=[("%ルシエル", "master", "女"), ("%ノア", "e1", "女"), ("%セラ", "e2", "女"), ("%ベル", "e3", "女"), ("%アザリエル", "boss", "女")],
    weak={"m1": "耳責め", "m2": "乳首責め", "m3": "本番", "e1": "キス", "e2": "本番", "e3": "乳首責め", "boss": "触手"},
    master=dict(
        name="堕天使　ルシエル", race="天使", sex="女", atk=500,
        explain=f"★得意技【黒い羽根】（黒い羽根で乳首を撫で続ける）で受けた相手の【{S}】+3（主人公は12枚で信徒＝敗北／男モンスターは6枚で聖歌隊として敵側へ）。{S}は主人公とモンスターが別々に持つ。【告解の囁き】は耳元の囁き。【光輪を嵌めて】（光輪の貞操帯＋ふたなり逆アナル）は指で2回ほぐした後にだけ出せる。ターン終了時、主人公の{S}の段階に応じて 魅了／魅了／寸止め／寸止め＋500。",
        techs=[T("告解の囁き", "耳責め", st=("魅了", 1)), T("黒い羽根", "乳首責め", fav=3), T("光輪を嵌めて", "本番", insert=True)],
        turn_end_ops=[[("status_p", "魅了", 1)], [("status_p", "魅了", 1)], [("status_p", "寸止め", 1)],
                      [("status_p", "寸止め", 1), ("dmg_p", 500)]]),
    mons={
        "e1": dict(name="聖歌隊　ノア", aid=4, lv=4, atk=450, hp=1400, rare="R", race="天使", sex="その他",
                   techs=[T("賛美の口づけ", "キス", fav=2, eff="&&キスエフェクト"), T("讃美歌", "魔法責め")],
                   explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+1。★得意技【賛美の口づけ】で受けた相手の{S}+2。【讃美歌】は歌声だけで頭を痺れさせる。",
                   summon_ops=[("add", 1)]),
        "e2": dict(name="聖油係　セラ", aid=5, lv=4, atk=550, hp=1500, rare="R", race="天使", sex="女",
                   techs=[T("聖油の指", "本番", fav=2, finger=True), T("聖油を塗り広げる", "ハグ")],
                   explain=f"★得意技【聖油の指】（聖油の指で前立腺を浄める）で受けた相手の{S}+2。【聖油を塗り広げる】は聖油で乳首を撫でる。自分のターン終了時：男モンスター1体に発情1ターン。",
                   end_ops=[("status_m_only", "発情", 1)]),
        "e3": dict(name="鐘守　ベル", aid=6, lv=4, atk=500, hp=1600, rare="R", race="天使", sex="その他",
                   techs=[T("鐘の振動", "乳首責め", fav=2), T("裸足で", "足コキ")],
                   explain=f"召喚時：男モンスター1体に魅了1ターン。★得意技【鐘の振動】（鐘の震えを乳首に当てる）で受けた相手の{S}+2。【裸足で】は素足で踏む。",
                   summon_ops=[("status_m_only", "魅了", 1)]),
        "boss": dict(name="堕天使長　アザリエル", aid=7, lv=7, atk=1200, hp=6000, rare="SR", race="天使", sex="女",
                     techs=[T("六枚の羽", "触手", fav=3), T("堕落の洗礼", "本番", insert=True, st=("寸止め", 1))],
                     explain=f"召喚時：男モンスター1体（いなければ主人公）の{S}+3。★得意技【六枚の羽】（羽で乳首とお尻を同時に）で受けた相手の{S}+3。【堕落の洗礼】（ふたなり逆アナル。指で2回ほぐした後だけ）で寸止め1ターン。固有効果【堕天の祝福】自分のターン終了時、主人公の{S}が6以上なら、男モンスター1体に魅了2ターン。",
                     summon_ops=[("add", 3)],
                     unique=dict(name="堕天の祝福", min=6, once=False, ops=[("status_m_only", "魅了", 2)])),
    },
    magic=std_magic(S, [("聖油の瓶", "add", 2), ("懺悔室", "trap", "寸止め"), ("黒い福音", "target", ("魅了", 1)),
                        ("天使の招集", "search", None), ("堕ちた光", "persist", None)]),
)
