#!/usr/bin/env python3
"""Gym MOD チェッカー。
usage: check.py file [file...]
  scen/*.txt  … 敗北シナリオ（字数5,000以上・書式）
  *.json      … セリフ（禁止文字）
  それ以外    … カードtxt（CRLF・default・if括弧・禁止文字・攻撃タイプ）
"""
import sys, re, json

ALLOWED = {"画像", "話者", "セリフ", "説明", "フラッシュ", "射精", "ウェイト", "画面色変化", "画面色解除"}
SPEAKERS = {"%ハヤテ", "%アイ", "%ソウ", "%ルイ", "%タイガ", "相手プレイヤー"}
BAD = set(",$%&#{}<>;!?")
NG_WORDS = ["少年", "子供", "子ども", "幼い", "ロリ", "少女", "ショタ", "童", "♪"]
OFFICIAL = set("通常攻撃 おっぱい パイズリ ぱふぱふ フェラ 手コキ 足コキ 脇コキ ハグ ふとももコキ 膝コキ 尻コキ 尻尾コキ 髪コキ キス スマタ 素股 魔法責め 触手 触手コキ 耳責め 乳首責め 強制自慰 パンチラ 息 本番".split())
IMG_RE = re.compile(r"^画像,#Gym/Gym_lose_(btl|onani|inochi|onedari)_(m1|m2|m3|e1|e2|e3|boss)\.png,1$")


def body_errs(body, i, errs):
    bad = sorted(set(c for c in body if c in BAD))
    if bad:
        errs.append(f"{i}: 禁止文字 {''.join(bad)}: {body[:40]}")
    for w in NG_WORDS:
        if w in body:
            errs.append(f"{i}: 禁止語 {w}: {body[:40]}")


def check_scen(path):
    """v4: #導入 / #プレイ / #結び の3区画。戻り値 (合計, errs, 区画別字数)"""
    errs = []
    lines = [l.rstrip("\r\n") for l in open(path, encoding="utf-8-sig")]
    lines = [l for l in lines if l.strip()]
    name = path.rsplit("/", 1)[-1][:-4]
    marks = [l for l in lines if l.startswith("#")]
    if marks != ["#導入", "#プレイ", "#結び"]:
        errs.append(f"区画の目印が #導入 #プレイ #結び の順になっていない: {marks}")
    if len(lines) < 2 or lines[0] != "#導入" or lines[1] != f"画像,#Gym/Gym_lose_{name}.png,1":
        errs.append("1行目が #導入、2行目が自分の画像行になっていない")
    sec = None
    cnt = {"#導入": 0, "#プレイ": 0, "#結び": 0}
    for i, l in enumerate(lines, 1):
        if l in cnt:
            sec = l
            continue
        cmd = l.split(",", 1)[0].strip()
        if cmd not in ALLOWED:
            errs.append(f"{i}: 使えないコマンド: {l[:40]}")
            continue
        if cmd in ("セリフ", "説明"):
            body = l.split(",", 1)[1] if "," in l else ""
            if not body.strip():
                errs.append(f"{i}: 本文が空")
            b = body.replace("\\n", "")
            body_errs(b, i, errs)
            if sec:
                cnt[sec] += len(b)
        elif cmd == "話者":
            sp = l.split(",", 1)[1].strip() if "," in l else ""
            if sp not in SPEAKERS:
                errs.append(f"{i}: 不明な話者 {sp}")
        elif cmd == "画像":
            if l != f"画像,#Gym/Gym_lose_{name}.png,1":
                errs.append(f"{i}: 画像行は自分の画像だけ: {l}")
    a, p, c = cnt["#導入"], cnt["#プレイ"], cnt["#結び"]
    if not (300 <= a <= 650):
        errs.append(f"導入の字数 {a}（350〜550字が目安、300〜650で合格）")
    if p < 6000:
        errs.append(f"プレイ描写の字数 {p}（6,000字以上必要）")
    if not (200 <= c <= 700):
        errs.append(f"結びの字数 {c}（300〜600字が目安、200〜700で合格）")
    return a + p + c, errs, (a, p, c)


def walk_json(o, errs, path="$"):
    if isinstance(o, str):
        body_errs(o, path, errs)
    elif isinstance(o, list):
        for k, v in enumerate(o):
            walk_json(v, errs, f"{path}[{k}]")
    elif isinstance(o, dict):
        for k, v in o.items():
            walk_json(v, errs, f"{path}.{k}")


def check_json(path):
    errs = []
    try:
        o = json.load(open(path, encoding="utf-8"))
    except Exception as e:
        return [f"JSONとして読めない: {e}"]
    walk_json(o, errs)
    return errs


def check_card(path):
    errs = []
    raw = open(path, "rb").read()
    txt = raw.decode("utf-8-sig")
    if re.search(rb"[^\r]\n", raw):
        errs.append("改行がCRLFでない箇所あり")
    lines = txt.split("\r\n")
    if lines[0].strip() != "default":
        errs.append("1行目がdefaultでない")
    depth = 0
    for i, l in enumerate(lines, 1):
        s = l.strip()
        if s.startswith(("if,", "while,", "case,")):
            nxt = lines[i].strip() if i < len(lines) else ""
            if nxt != "{":
                errs.append(f"{i}: if/case の次が {{ でない: {s[:40]}")
        if s == "{":
            depth += 1
        elif s == "}":
            depth -= 1
        elif s == "}else{":
            if depth <= 0:
                errs.append(f"{i}: else の位置")
        elif s.startswith("else"):
            errs.append(f"{i}: 単独 else")
        if s.startswith("@"):
            if depth != 0:
                errs.append(f"{i}: セクション開始時に括弧が閉じていない (depth={depth})")
            depth = 0
        if depth < 0:
            errs.append(f"{i}: 閉じ括弧が多い")
            depth = 0
        for cmd in ("セリフ,", "説明,", "アラート,", "技名表示,"):
            if s.startswith(cmd):
                body = re.sub(r"\{\$[^{}]+\}", "", s[len(cmd):]).replace("\\n", "")
                body_errs(body, i, errs)
        m = re.match(r"(攻撃タイプランダム変更|主人公攻撃タイプ弱点付与|攻撃タイプ固定),(.*)", s)
        if m:
            parts = m.group(2).split(",")
            names = parts if m.group(1) == "攻撃タイプランダム変更" else parts[:1]
            for nm in names:
                if nm not in OFFICIAL:
                    errs.append(f"{i}: 非公式の攻撃タイプ {nm}")
        m = re.match(r"if,攻撃タイプ,==,(.*)", s)
        if m and m.group(1) not in OFFICIAL:
            errs.append(f"{i}: 非公式の攻撃タイプ {m.group(1)}")
        if re.match(r"^(画像|画像表示|話者生成),.*#", s):
            errs.append(f"{i}: 画像を直接パスで指定している: {s[:50]}")
    if depth != 0:
        errs.append(f"末尾で括弧が閉じていない depth={depth}")
    return errs


if __name__ == "__main__":
    ok = True
    for p in sys.argv[1:]:
        if "/scen/" in p:
            n, errs, (a, pl, c) = check_scen(p)
            st = "OK" if not errs else "NG"
            print(f"{st} {p} 合計={n} 導入={a} プレイ={pl} 結び={c}")
        elif p.endswith(".json"):
            errs = check_json(p)
            st = "OK" if not errs else "NG"
            print(f"{st} {p}")
        else:
            errs = check_card(p)
            st = "OK" if not errs else "NG"
            print(f"{st} {p}")
        for e in errs[:30]:
            print("   ", e)
        if st == "NG":
            ok = False
    sys.exit(0 if ok else 1)
